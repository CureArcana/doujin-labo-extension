(function () {
  const DL = self.DL;

  const els = {
    issue: document.getElementById("opt-issue"),
    issued: document.getElementById("opt-issued"),
    code: document.getElementById("opt-code"),
    codeTtl: document.getElementById("opt-code-ttl"),
    redeemInput: document.getElementById("opt-redeem-input"),
    redeem: document.getElementById("opt-redeem"),
    redeemMsg: document.getElementById("opt-redeem-msg"),
    deviceId: document.getElementById("opt-device-id"),
    groupId: document.getElementById("opt-group-id"),
    count: document.getElementById("opt-count"),
    unread: document.getElementById("opt-unread"),
    refresh: document.getElementById("opt-refresh"),
    exportBtn: document.getElementById("opt-export"),
    importFile: document.getElementById("opt-import-file"),
    ioMsg: document.getElementById("opt-io-msg"),
    notifyTest: document.getElementById("opt-notify-test"),
    purge: document.getElementById("opt-purge"),
    purgeMsg: document.getElementById("opt-purge-msg"),
    verCurrent: document.getElementById("opt-ver-current"),
    verLatest: document.getElementById("opt-ver-latest"),
    verChecked: document.getElementById("opt-ver-checked"),
    checkUpdate: document.getElementById("opt-check-update"),
    updateLink: document.getElementById("opt-update-link"),
    updateMsg: document.getElementById("opt-update-msg"),
  };

  function setMsg(target, text, kind) {
    target.textContent = text;
    target.hidden = !text;
    target.className = "opt-msg" + (kind ? " " + kind : "");
  }

  async function refreshStatus() {
    const store = await DL.getStore();
    const dev = store.dl_fav_device;
    els.deviceId.textContent = dev?.device_id || "—";
    els.groupId.textContent = dev?.group_id || "—";
    const s = await DL.apiSummary();
    els.count.textContent = s ? String(s.count) : "—";
    els.unread.textContent = s ? String(s.unread_alert_count) : "—";
  }

  // -------- pairing --------
  els.issue.addEventListener("click", async () => {
    els.issue.disabled = true;
    els.issued.hidden = true;
    const res = await DL.apiPairIssue();
    els.issue.disabled = false;
    if (!res?.code) {
      alert("コードの発行に失敗しました。時間をおいて再度お試しください。");
      return;
    }
    els.code.textContent = res.code;
    els.codeTtl.textContent = `${res.ttl_minutes} 分間有効`;
    els.issued.hidden = false;
    setTimeout(() => { els.issued.hidden = true; }, res.ttl_minutes * 60 * 1000);
  });

  els.redeemInput.addEventListener("input", (e) => {
    e.target.value = e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8);
    setMsg(els.redeemMsg, "");
  });

  els.redeem.addEventListener("click", async () => {
    const code = els.redeemInput.value.trim();
    if (code.length !== 8) {
      setMsg(els.redeemMsg, "8 桁のコードを入力してください。", "err");
      return;
    }
    els.redeem.disabled = true;
    const res = await DL.apiPairRedeem(code);
    els.redeem.disabled = false;
    if (!res?.ok) {
      setMsg(els.redeemMsg, res?.detail || "コードが無効か有効期限切れです。", "err");
      return;
    }
    setMsg(els.redeemMsg, `同期しました。合計 ${res.favorites_count} 件のお気に入りを共有しています。`, "ok");
    els.redeemInput.value = "";
    refreshStatus();
  });

  // -------- backup / export / import --------
  els.exportBtn.addEventListener("click", async () => {
    els.exportBtn.disabled = true;
    setMsg(els.ioMsg, "エクスポート中…");
    const list = await DL.apiList();
    els.exportBtn.disabled = false;
    if (!list) { setMsg(els.ioMsg, "取得に失敗しました。", "err"); return; }
    const payload = {
      exported_at: new Date().toISOString(),
      version: 1,
      count: list.items?.length || 0,
      items: (list.items || []).map((it) => ({
        work_code: it.work_code,
        alert_threshold_yen: it.alert_threshold_yen,
        added_price: it.added_price,
        title: it.work?.title || null,
      })),
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    const stamp = new Date().toISOString().slice(0, 10);
    a.href = url;
    a.download = `doujin-labo-watchlist-${stamp}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    setMsg(els.ioMsg, `${payload.count} 件をエクスポートしました。`, "ok");
  });

  els.importFile.addEventListener("change", async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setMsg(els.ioMsg, "読み込み中…");
    try {
      const text = await file.text();
      const payload = JSON.parse(text);
      const items = Array.isArray(payload?.items) ? payload.items : [];
      if (!items.length) throw new Error("items が空です");
      let ok = 0, dup = 0, fail = 0;
      for (const it of items) {
        if (!it.work_code) { fail++; continue; }
        const res = await DL.apiAdd({
          work_code: it.work_code,
          added_price: it.added_price,
          alert_threshold_yen: it.alert_threshold_yen,
        });
        if (!res) fail++;
        else if (res.was_dup) dup++;
        else ok++;
      }
      setMsg(els.ioMsg, `新規 ${ok} 件 / 重複 ${dup} 件 / 失敗 ${fail} 件`, ok + dup > 0 ? "ok" : "err");
      refreshStatus();
    } catch (err) {
      setMsg(els.ioMsg, `読み込み失敗: ${err.message}`, "err");
    } finally {
      e.target.value = "";
    }
  });

  // -------- notification test --------
  els.notifyTest.addEventListener("click", () => {
    try {
      chrome.notifications.create(`dl-test-${Date.now()}`, {
        type: "basic",
        iconUrl: chrome.runtime.getURL("icons/icon-128.png"),
        title: "💗 同人ラボ テスト通知",
        message: "通知が届いていれば設定は完了しています。",
        priority: 1,
      });
    } catch (e) {
      alert("通知 API が利用できません。Chrome の権限設定を確認してください。");
    }
  });

  // -------- purge (delete all favorites in group) --------
  els.purge.addEventListener("click", async () => {
    if (!confirm("本当に全てのお気に入りを削除しますか？\nペアリング済みの他端末からも消えます。元に戻せません。")) return;
    els.purge.disabled = true;
    setMsg(els.purgeMsg, "削除中…");
    const list = await DL.apiList();
    if (!list) { setMsg(els.purgeMsg, "取得に失敗しました。", "err"); els.purge.disabled = false; return; }
    let ok = 0, fail = 0;
    for (const it of list.items || []) {
      const r = await DL.apiRemove(it.work_code);
      if (r) ok++; else fail++;
    }
    els.purge.disabled = false;
    setMsg(els.purgeMsg, `${ok} 件を削除しました${fail > 0 ? ` (失敗 ${fail} 件)` : ""}`, fail === 0 ? "ok" : "err");
    refreshStatus();
  });

  // -------- refresh --------
  els.refresh.addEventListener("click", refreshStatus);

  // 版の表示は manifest から取る (DL-116 2026-10-08: html に v0.6.3 が固定で残っていた)
  try {
    const sub = document.querySelector(".opt-sub");
    if (sub) sub.textContent = "Chrome 拡張 v" + chrome.runtime.getManifest().version;
  } catch (_) {}

  // -------- DL-146: 更新を確認 --------
  const CURRENT_VER = (function () { try { return chrome.runtime.getManifest().version; } catch (_) { return "?"; } })();

  function fmtWhen(ts) {
    if (!ts) return "まだ確認していません";
    const d = new Date(ts);
    const p = (n) => String(n).padStart(2, "0");
    return d.getFullYear() + "/" + p(d.getMonth() + 1) + "/" + p(d.getDate()) + " " + p(d.getHours()) + ":" + p(d.getMinutes());
  }

  // 配布元を固定する (version.json の中身で任意の URL へ飛ばさない)
  function showUpdateLink(url) {
    if (!els.updateLink) return;
    if (typeof url === "string" && url.startsWith("https://curearcana.github.io/")) els.updateLink.href = url;
    els.updateLink.hidden = false;
  }

  // 保存済みの結果を先に描く (ボタンを押す前でも「前回の確認」が読める)
  function paintStoredUpdate() {
    if (els.verCurrent) els.verCurrent.textContent = "v" + CURRENT_VER;
    try {
      chrome.storage.local.get("dl_update", (v) => {
        const u = v && v.dl_update;
        if (!u) return;
        if (els.verChecked) els.verChecked.textContent = fmtWhen(u.checked_at);
        if (u.latest) {
          if (els.verLatest) els.verLatest.textContent = "v" + u.latest;
          showUpdateLink(u.url);
        }
      });
    } catch (_) {}
  }

  async function doCheckUpdate() {
    if (!els.checkUpdate) return;
    els.checkUpdate.disabled = true;
    const label = els.checkUpdate.textContent;
    els.checkUpdate.textContent = "確認中…";
    setMsg(els.updateMsg, "", null);
    const r = await new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage({ type: "dl:check_update" }, (res) => {
          void chrome.runtime.lastError; // 読まないと Unchecked runtime.lastError が出る
          resolve(res || { ok: false, error: "no_response" });
        });
      } catch (_) { resolve({ ok: false, error: "no_response" }); }
    });
    els.checkUpdate.disabled = false;
    els.checkUpdate.textContent = label;
    if (els.verChecked) els.verChecked.textContent = fmtWhen((r && r.checked_at) || Date.now());
    if (!r || !r.ok) {
      if (els.verLatest) els.verLatest.textContent = "—";
      setMsg(els.updateMsg, "配布ページに繋がりませんでした。時間をおいて、もう一度お試しください。", "err");
      return;
    }
    if (els.verLatest) els.verLatest.textContent = "v" + r.remote;
    if (r.newer) {
      showUpdateLink(r.url);
      setMsg(els.updateMsg, "新しい版 v" + r.remote + " があります (いまは v" + r.current + ")。ダウンロードページから入れ替えてください。", "ok");
    } else {
      if (els.updateLink) els.updateLink.hidden = true;
      setMsg(els.updateMsg, "最新版です (v" + r.current + ")。", "ok");
    }
  }

  if (els.checkUpdate) els.checkUpdate.addEventListener("click", doCheckUpdate);
  paintStoredUpdate();

  DL.ensureDevice().then(refreshStatus);
})();
