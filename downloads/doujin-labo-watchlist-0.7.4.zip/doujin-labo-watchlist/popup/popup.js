(function () {
  const DL = self.DL;
  const yen = (n) => (n == null ? "—" : Number(n).toLocaleString() + "円");
  const CAT_LABEL = { comic: "漫画", cg: "CG", voice: "ボイス", movie: "動画", game: "ゲーム", illust: "CG" };
  const STORE_LABEL = { dlsite: "DLsite", fanza: "FANZA" };

  const state = {
    items: [],
    activeStore: "all",
    activeCat: "",       // "" = すべて
    onlyHit: false,
    editingThreshold: null, // 通知価格編集中の work_code (null=非編集)
    editError: null,        // 編集中の入力エラー文言
    focusEditor: false,     // エディタを「開いた瞬間」だけ true (再描画のたびに focus を奪わない)
  };

  // reload の世代番号と保存中フラグ。
  // PATCH 中に 10 秒ポーリング / onLiveChange / focus の reload が割り込むと、サーバーの旧値で
  // 楽観更新が巻き戻る。古い GET が後から解決して新しい値を踏むのも防ぐ (v0.7.2)。
  let reloadSeq = 0;
  let saving = false;

  const els = {
    list: document.getElementById("pop-list"),
    hitChip: document.getElementById("pop-hit-chip"),
    hitCount: document.getElementById("pop-hit-count"),
    refresh: document.getElementById("pop-refresh"),
    footinfo: document.getElementById("pop-footinfo"),
    tabs: Array.from(document.querySelectorAll(".pop-tab")),
    cats: Array.from(document.querySelectorAll(".pop-cat")),
    onlyHitToggle: document.getElementById("pop-only-hit"),
    counts: {
      all: document.querySelector("[data-count-all]"),
      dlsite: document.querySelector("[data-count-dlsite]"),
      fanza: document.querySelector("[data-count-fanza]"),
    },
  };

  function el(tag, props, ...children) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(props || {})) {
      if (k === "class") e.className = v;
      else if (k === "html") e.innerHTML = v;
      else if (k === "style" && typeof v === "object") Object.assign(e.style, v);
      else if (k.startsWith("on") && typeof v === "function") e.addEventListener(k.slice(2), v);
      else if (v != null && v !== false) e.setAttribute(k, v);
    }
    for (const c of children.flat()) {
      if (c == null || c === false) continue;
      e.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
    }
    return e;
  }

  // アイコンは inline SVG (絵文字は使わない。サイトの unified-nav の Icons と同じ流儀)
  const ICONS = {
    check: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M3 8.5l3.2 3.2L13 4.8"/></svg>',
    plus: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M8 3v10M3 8h10"/></svg>',
    close: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M4 4l8 8M12 4l-8 8"/></svg>',
    // 鉛筆: 「ここは押すと編集できる」の合図。通知価格の帯の先頭に必ず出す
    pencil: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M11.2 2.4a1.7 1.7 0 0 1 2.4 2.4L5.9 12.5l-3.2.8.8-3.2z"/><path d="M10 3.6l2.4 2.4"/></svg>',
    heart: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"><path d="M12 20.5s-7.5-4.6-7.5-10A4.1 4.1 0 0 1 12 7.3a4.1 4.1 0 0 1 7.5 3.2c0 5.4-7.5 10-7.5 10z"/></svg>',
  };
  function ico(name) {
    const s = document.createElement("span");
    s.className = "pop-ico";
    s.setAttribute("aria-hidden", "true");
    s.innerHTML = ICONS[name] || "";
    return s;
  }

  function itemMatchesStore(it, store) {
    if (store === "all") return true;
    // items.stores から判定 (両ストア持ちの場合はどちらのタブでも表示)
    return (it.stores || []).some((s) => s.site === store);
  }

  function itemMatchesCat(it, cat) {
    if (!cat) return true;
    const c = it.work?.category || "";
    // cg と illust は等価扱い
    if (cat === "cg") return c === "cg" || c === "illust";
    return c === cat;
  }

  function itemMatchesHit(it, onlyHit) {
    return !onlyHit || it.alert_hit;
  }

  // 割引率 → tier クラス (10% 刻み、90%+ は t90)。サイト `.dl-offbar` と同じ配色を購入ボタンに適用する。
  function offTier(p) {
    if (!p || p <= 0) return "";
    if (p >= 90) return " t90";
    return " t" + (Math.floor(p / 10) * 10);
  }

  function renderStoreRow(store, item) {
    const isBest = store.site === item.best_site && (item.stores || []).length > 1;
    // /go/{site}/{code} 経由。doujin-labo.net の 302 route が dlaf / al アフィ URL を組んで転送する
    // (拡張が直接 dlaf を組むより規約整合性が高い + env / 承認状態の切替に自動追随)
    const goUrl = `https://doujin-labo.net/go/${store.site}/${encodeURIComponent(store.work_code)}`;
    const tierCls = offTier(store.off_pct);
    const goBtn = el("a", {
      class: "pop-store-go" + tierCls,
      href: goUrl,
      target: "_blank",
      rel: "noopener sponsored",
      title: `${STORE_LABEL[store.site] || store.site} で購入ページを開く`,
      onclick: (e) => {
        // カード全体の onclick (作品詳細ページを開く) が発火しないように止める
        e.stopPropagation();
        // popup 内 a[target=_blank] は Chrome が新規タブを開くが、popup 側は残る。
        // 明示 tabs.create + close で他の card クリックと挙動を揃える
        e.preventDefault();
        chrome.tabs.create({ url: goUrl });
        window.close();
      },
    });
    // 「購入」ボタン: テキストを大きく + 矢印も拡大。割引率で背景色をサイトと揃える (tierCls)。
    goBtn.innerHTML = '<span class="pop-store-go-label">購入</span><svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8h9"/><path d="M9 4l5 4-5 4"/></svg>';

    // 列位置を固定: [chip] [price 右寄せ] [was] [off%] [購入]
    // - 割引無しでも was/off セルは空で描画して列を保持 → 上下行で ¥ と % が縦にピタリ揃う
    // - 「最安」は行の背景色 (.best) と価格文字色で表現 → 中央列が動かない
    const wasCell = store.list_price && store.list_price > store.price
      ? el("span", { class: "pop-store-was" }, yen(store.list_price))
      : el("span", { class: "pop-store-was empty" });
    const offCell = store.off_pct > 0
      ? el("span", { class: "pop-store-off" }, `-${store.off_pct}%`)
      : el("span", { class: "pop-store-off empty" });

    const chip = el("span", { class: `pop-store-chip ${store.site}` }, STORE_LABEL[store.site] || store.site);
    if (isBest) chip.setAttribute("title", "最安");

    const row = el("div", { class: "pop-store-row" + (isBest ? " best" : "") },
      chip,
      el("span", { class: "pop-store-price" }, yen(store.price)),
      wasCell,
      offCell,
      goBtn,
    );
    return row;
  }

  // 片方のストアが取扱なしの時のプレースホルダ行 (2 行ぶんの高さを保証)
  function renderMissingStoreRow(site) {
    return el("div", { class: "pop-store-row missing" },
      el("span", { class: `pop-store-chip ${site} muted` }, STORE_LABEL[site] || site),
      el("span", { class: "pop-store-price muted" }, "取扱なし"),
      el("span", { class: "pop-store-was empty" }),
      el("span", { class: "pop-store-off empty" }),
      el("span", { class: "pop-store-go empty" }),
    );
  }

  // 通知価格エディタ (v0.7.2 で拡大): サークル名行の代わりに本文幅いっぱいで出す 1 枚。
  // [通知価格] [¥ 入力] [保存] [×] + 「現在の価格にする」の近道。
  // 保存すると DL.apiPatch → 同一 group_id の他端末は次回 fetch で自動反映。
  // Enter=保存 / Escape=キャンセル。
  function renderThresholdEditor(it) {
    const current = it.alert_threshold_yen ?? "";
    const input = el("input", {
      type: "number",
      min: "0",
      step: "10",
      inputmode: "numeric",
      value: current === "" ? "" : String(current),
      placeholder: "例: 500",
      class: "pop-th-input",
      "aria-label": "通知価格 (円)",
      onclick: (e) => e.stopPropagation(),
      onkeydown: (e) => {
        e.stopPropagation();
        if (e.key === "Enter") { e.preventDefault(); saveThreshold(it, input.value); }
        else if (e.key === "Escape") { e.preventDefault(); cancelThresholdEdit(); }
      },
    });
    // 単位は表示と揃えて「円」後置 (ストリップ・ピル・価格行が全部「○○円」)
    const field = el("label", { class: "pop-th-field", onclick: (e) => e.stopPropagation() },
      input,
      el("span", { class: "pop-th-yen", "aria-hidden": "true" }, "円"),
    );
    const save = el("button", {
      class: "pop-th-save",
      type: "button",
      title: "保存 (Enter)",
      onclick: (e) => { e.stopPropagation(); saveThreshold(it, input.value); },
    }, ico("check"), "保存");
    const cancel = el("button", {
      class: "pop-th-cancel",
      type: "button",
      title: "キャンセル (Esc)",
      "aria-label": "キャンセル",
      onclick: (e) => { e.stopPropagation(); cancelThresholdEdit(); },
    }, ico("close"));
    // 160px に収めるため 2 段: [入力] / [保存][×]
    const wrap = el("div", {
      class: "pop-th-editor",
      onclick: (e) => e.stopPropagation(),
    },
      el("div", { class: "pop-th-editor-label" }, ico("pencil"), "通知価格"),
      field,
      el("div", { class: "pop-th-editor-row" }, save, cancel),
    );
    if (state.editError) {
      wrap.appendChild(el("div", { class: "pop-th-error", role: "alert" }, state.editError));
    }
    // 「今の値段になったら知らせて」が一番多いので、1 クリックでそこまで済ませる
    // (160px に収めるため「現在の価格 …」より短く)
    if (it.current_price != null) {
      wrap.appendChild(el("button", {
        class: "pop-th-quick",
        type: "button",
        title: `現在の価格 ${yen(it.current_price)} を通知価格にして保存`,
        onclick: (e) => { e.stopPropagation(); saveThreshold(it, String(it.current_price)); },
      }, `いま ${yen(it.current_price)} で通知`));
    }
    // フォーカスは「開いた瞬間」だけ。毎回の再描画で奪うと、押したタブから focus が飛ぶ
    if (state.focusEditor) {
      state.focusEditor = false;
      setTimeout(() => { try { input.focus(); input.select(); } catch (e) {} }, 0);
    }
    return wrap;
  }

  async function saveThreshold(it, rawValue) {
    const trimmed = String(rawValue ?? "").trim();
    if (trimmed === "") {
      // input[type=number] は "abc" でも value が "" になるので、黙って閉じずに知らせる
      state.editError = "金額を入れてください（0 以上の整数）";
      render();
      return;
    }
    const num = Number(trimmed);
    if (!Number.isFinite(num) || num < 0) {
      state.editError = "0 以上の整数を入れてください";
      render();
      return;
    }
    const rounded = Math.round(num);
    const item = state.items.find((x) => x.work_code === it.work_code);
    // 失敗したら戻せるように元の値を控える
    const prev = item ? { th: item.alert_threshold_yen, hit: item.alert_hit } : null;
    // 楽観的更新: UI を先に更新してから API 送信
    if (item) {
      item.alert_threshold_yen = rounded;
      if (item.current_price != null) item.alert_hit = item.current_price <= rounded;
    }
    state.editingThreshold = null;
    state.editError = null;
    render();
    // apiPatch → 成功時に _touchLive → 他 Chrome コンテキストは onLiveChange で reload
    // → 同一 group_id の他端末 (スマホ / PC ブラウザ) は次のポーリングで反映
    saving = true;
    let res = null;
    try {
      res = await DL.apiPatch(it.work_code, rounded);
    } finally {
      saving = false;
    }
    if (!res) {
      // 失敗: サーバーは変わっていないので、楽観更新を戻して知らせる (reload は呼ばない)
      if (item && prev) { item.alert_threshold_yen = prev.th; item.alert_hit = prev.hit; }
      render();
      els.footinfo.textContent = "通知価格の更新に失敗しました";
      return;
    }
    // fresh な alert_hit 状態を取り直す
    reload();
  }

  function cancelThresholdEdit() {
    state.editingThreshold = null;
    state.editError = null;
    render();
  }

  function beginThresholdEdit(work_code) {
    if (state.editingThreshold === work_code) return; // 編集中に押し直しても入力を飛ばさない
    state.editingThreshold = work_code;
    state.editError = null;
    state.focusEditor = true;
    render();
  }

  function renderCard(it) {
    const w = it.work || {};
    const isHit = !!it.alert_hit;
    const detailUrl = `https://doujin-labo.net/w/${encodeURIComponent(it.work_code)}`;
    const thumbUrl = w.thumbnail_url;
    const catLabel = CAT_LABEL[w.category] || null;

    const card = el("div", {
      class: "pop-card" + (isHit ? " is-hit" : ""),
      "data-code": it.work_code,
      onclick: (e) => {
        if (e.target.closest(".pop-remove")) return;
        chrome.tabs.create({ url: detailUrl });
        window.close();
      },
    });

    const thumb = el("span", { class: "pop-thumb" });
    if (thumbUrl) thumb.appendChild(el("img", { src: thumbUrl, alt: "", loading: "lazy" }));
    else thumb.innerHTML = '<span class="ph"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="3" y="4" width="18" height="16"></rect><path d="M3 16l5-4 4 3 3-2 6 4"></path><circle cx="8.5" cy="9" r="1.4"></circle></svg></span>';

    // 通知価格の帯 (v0.7.3): 到達 / 未到達 / 未設定 の 3 状態とも、サムネ底部の同じ位置に出す。
    // 先頭の鉛筆が「押せば編集できる」の合図。右のタグが状態 (到達 / あと ○円)。
    // button なのでキーボードでも届く。
    const editingThis = state.editingThreshold === it.work_code;
    const th = it.alert_threshold_yen;
    const cur = it.current_price;
    let stripCls, stripText, stripTag, stripLabel;
    if (th == null) {
      stripCls = "is-unset";
      stripText = "通知価格を設定";
      stripTag = null;
      stripLabel = "通知価格を設定";
    } else if (isHit) {
      stripCls = "is-hit";
      stripText = `通知 ${yen(th)}`;
      stripTag = "到達";
      stripLabel = `通知価格 ${yen(th)} を編集（到達）`;
    } else {
      const rest = cur != null ? Math.max(0, cur - th) : null;
      stripCls = "is-near";
      stripText = `通知 ${yen(th)}`;
      stripTag = rest != null && rest > 0 ? `あと ${yen(rest)}` : null;
      stripLabel = `通知価格 ${yen(th)} を編集`
        + (rest != null && rest > 0 ? `（あと ${yen(rest)}）` : "");
    }
    const strip = el("button", {
      class: `pop-thumb-strip ${stripCls}`,
      type: "button",
      "aria-label": stripLabel,
      title: stripLabel,
      onclick: (e) => { e.stopPropagation(); beginThresholdEdit(it.work_code); },
    },
      el("span", { class: "pop-thumb-strip-label" },
        ico("pencil"),
        el("span", { class: "pop-thumb-strip-text" }, stripText),
      ),
      stripTag ? el("span", { class: "pop-thumb-strip-status" }, stripTag) : null,
    );
    thumb.appendChild(strip);

    // 編集中はサムネに重ねる (本文に差し込むとカードが伸びて崩れる。重ねれば右の価格行が見えたまま)
    if (editingThis) thumb.appendChild(renderThresholdEditor(it));
    card.appendChild(thumb);

    const body = el("div", { class: "pop-body" });

    // タイトル (カテゴリ chip をインラインで先頭に埋める → 独立した eyebrow 行を廃止)
    const titleEl = el("div", { class: "pop-title" });
    if (catLabel) titleEl.appendChild(el("span", { class: "pop-cat-chip" }, catLabel));
    titleEl.appendChild(document.createTextNode(w.title || it.work_code));
    body.appendChild(titleEl);

    // メタ行はサークル名だけ (通知価格まわりは全部サムネの帯へ移した v0.7.3)。
    // 高さは固定 → 通知価格の状態が変わってもカードが伸び縮みしない
    const metaLine = el("div", { class: "pop-meta-line" });
    metaLine.appendChild(el("span", { class: "pop-circle" }, w.circle_name || ""));
    body.appendChild(metaLine);

    // 価格行群: DLsite / FANZA を常に 2 行描画。取扱が無いストアは "取扱なし" プレースホルダで
    // 縦幅を統一 (カード同士の高さが揃う)。
    const prices = el("div", { class: "pop-prices" });
    const storesByKey = Object.fromEntries((it.stores || []).map((s) => [s.site, s]));
    for (const site of ["dlsite", "fanza"]) {
      const store = storesByKey[site];
      prices.appendChild(store ? renderStoreRow(store, it) : renderMissingStoreRow(site));
    }
    body.appendChild(prices);

    card.appendChild(body);

    const remove = el("button", {
      class: "pop-remove",
      title: "お気に入りから外す",
      onclick: async (e) => {
        e.stopPropagation();
        if (!confirm("お気に入りから外しますか？")) return;
        remove.disabled = true;
        const ok = await DL.apiRemove(it.work_code);
        if (ok) {
          // 編集中のカード自身を消した場合に editingThreshold が残ると reload が止まる
          if (state.editingThreshold === it.work_code) cancelThresholdEdit();
          state.items = state.items.filter((x) => x.work_code !== it.work_code);
          render();
        }
      },
    });
    remove.innerHTML = '<svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 4l8 8M12 4l-8 8"></path></svg><span>解除</span>';
    card.appendChild(remove);

    return card;
  }

  function render() {
    const items = state.items;
    // counts by store (両ストア持ちは両方カウント)
    const counts = { all: items.length, dlsite: 0, fanza: 0 };
    for (const it of items) {
      const stores = new Set((it.stores || []).map((s) => s.site));
      if (stores.has("dlsite")) counts.dlsite++;
      if (stores.has("fanza")) counts.fanza++;
    }
    els.counts.all.textContent = counts.all;
    els.counts.dlsite.textContent = counts.dlsite;
    els.counts.fanza.textContent = counts.fanza;

    const hits = items.filter((i) => i.alert_hit).length;
    if (hits > 0) {
      els.hitChip.hidden = false;
      els.hitCount.textContent = String(hits);
    } else {
      els.hitChip.hidden = true;
    }

    const filtered = items
      .filter((i) => itemMatchesStore(i, state.activeStore))
      .filter((i) => itemMatchesCat(i, state.activeCat))
      .filter((i) => itemMatchesHit(i, state.onlyHit));
    filtered.sort((a, b) => {
      if (!!b.alert_hit - !!a.alert_hit !== 0) return !!b.alert_hit - !!a.alert_hit;
      return (b.added_at || "").localeCompare(a.added_at || "");
    });

    // 編集中のカードがフィルタの外に出た (タブ / カテゴリ / 到達のみ切替、別端末での削除) まま
    // editingThreshold が残ると、reload() が永久に skip されて popup を閉じるまで更新が止まる
    if (state.editingThreshold != null
        && !filtered.some((i) => i.work_code === state.editingThreshold)) {
      state.editingThreshold = null;
      state.editError = null;
    }

    els.list.innerHTML = "";
    if (!filtered.length) {
      const empty = el("div", { class: "pop-empty" });
      empty.innerHTML = `
        <div class="pop-empty-heart" aria-hidden="true">${ICONS.heart}</div>
        <div class="pop-empty-title">${items.length === 0 ? "お気に入りはまだありません" : "該当する作品がありません"}</div>
        <div class="pop-empty-sub">${items.length === 0
          ? "DLsite / FANZA の作品ページを開くと、パネルから追加できます。"
          : "フィルタを切り替えてみてください。"}</div>
      `;
      els.list.appendChild(empty);
    } else {
      for (const it of filtered) els.list.appendChild(renderCard(it));
    }

    // 右に「価格更新 毎日 4:30頃」が並ぶので短く (旧: 「… 件表示（DLsite n ／ FANZA n）」)
    els.footinfo.textContent = `${filtered.length} / ${items.length} 件`;
  }

  // 起動時: chrome.storage の snapshot を即描画してから API 取得へ。
  // popup は開くたび新プロセスなので、これが無いと空 → API 待ち → 表示となり体感が遅い。
  async function primeFromCache() {
    try {
      const snap = await DL.getSnapshot();
      if (snap?.items?.length) {
        state.items = snap.items;
        render();
        const ts = snap.updated_at ? new Date(snap.updated_at) : null;
        els.footinfo.textContent = ts
          ? `キャッシュ表示中 (${ts.toLocaleTimeString("ja-JP", { hour: "2-digit", minute: "2-digit" })}) ・ 更新中…`
          : "更新中…";
        return true;
      }
    } catch (e) { /* noop */ }
    return false;
  }

  async function reload() {
    // 編集中・保存中は skip: 入力中の値や楽観更新がリロードで潰れないように
    if (state.editingThreshold != null || saving) return;
    const seq = ++reloadSeq;
    const hadCache = state.items.length > 0;
    if (!hadCache) els.footinfo.textContent = "読み込み中…";
    const j = await DL.apiList();
    // 後から始まった reload が先に終わっていたら、古い応答で上書きしない
    if (seq !== reloadSeq) return;
    if (!j) {
      els.footinfo.textContent = hadCache
        ? "更新できませんでした（表示はキャッシュ）"
        : "取得できませんでした";
      return;
    }
    state.items = j.items || [];
    render();
    // 次回オープン時の即時表示用にスナップショット保存
    try { DL.setSnapshot({ items: state.items }); } catch (e) {}
    DL.apiMarkRead();
    // バッジ / アイコン色は background.js 側で alert_hit_count を再取得して反映する
    try { chrome.runtime.sendMessage({ type: "poll_now" }); } catch (e) { /* noop */ }
  }

  // wire tabs
  for (const btn of els.tabs) {
    btn.addEventListener("click", () => {
      for (const b of els.tabs) {
        b.classList.toggle("is-on", b === btn);
        b.setAttribute("aria-pressed", String(b === btn));
      }
      state.activeStore = btn.dataset.store;
      render();
    });
  }
  for (const btn of els.cats) {
    btn.addEventListener("click", () => {
      for (const b of els.cats) {
        b.classList.toggle("is-on", b === btn);
        b.setAttribute("aria-pressed", String(b === btn));
      }
      state.activeCat = btn.dataset.cat;
      render();
    });
  }
  els.onlyHitToggle.addEventListener("change", (e) => {
    state.onlyHit = e.target.checked;
    render();
  });
  els.refresh.addEventListener("click", async () => {
    els.refresh.disabled = true;
    try { chrome.runtime.sendMessage({ type: "poll_now" }); } catch (e) { /* noop */ }
    await reload();
    els.refresh.disabled = false;
  });

  // -------- live sync --------
  // 1) 別の extension context (in-page panel / options / background poll) が
  //    mutation を起こしたら chrome.storage.onChanged で即 reload。
  // 2) doujin-labo.net web page からの編集は storage を触らないため、10s poll で拾う。
  // 3) 画面表示に戻ってきた瞬間 (visibilitychange, focus) にも reload。
  DL.onLiveChange(() => { reload(); });
  const pollTimer = setInterval(() => { reload(); }, 10000);
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") reload();
  });
  window.addEventListener("focus", () => { reload(); });
  window.addEventListener("beforeunload", () => { clearInterval(pollTimer); });

  // キャッシュ即描画 → 裏で API 取得。ネットが遅くても空白が出ない。
  primeFromCache().finally(reload);
})();

// DL-146: 設定画面を開く (更新の確認・同期コード・バックアップはあそこ)
(function () {
  const b = document.getElementById("pop-options");
  if (!b) return;
  b.addEventListener("click", () => {
    try { chrome.runtime.openOptionsPage(() => window.close()); } catch (e) { window.close(); }
  });
})();

// 更新の案内: background の checkUpdate が見つけた新しい版を帯で知らせる (ストア外配布は自動更新されない)
(function () {
  const bar = document.getElementById("pop-update");
  if (!bar) return;
  try {
    chrome.storage.local.get("dl_update", (v) => {
      const u = v?.dl_update;
      if (!u?.latest || !u.url) return;
      bar.textContent = `新しい版 v${u.latest} があります (いま v${chrome.runtime.getManifest().version}) → 更新方法を見る`;
      bar.href = u.url;
      bar.hidden = false;
    });
  } catch (e) { /* noop */ }
})();
