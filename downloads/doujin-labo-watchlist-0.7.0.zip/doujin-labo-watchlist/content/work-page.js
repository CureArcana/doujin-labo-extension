// doujin-labo Chrome 拡張 - 作品ページへのパネル注入 (DLsite / FANZA 共通)
//
// dlsite-price-tracker (稼働実績あり) の src/content/work-page.js + lib/dom.js を
// 骨子として、doujin-labo の API/ハート/価格アラート仕様に合わせて再構築。
//
// キーポイント:
//   - URL からの product_id 抽出は複数接頭辞を許容 (RJ/BJ/VJ/WJ/RE/BR/VR/VE/WE/BE + d_)
//   - FANZA の cid は `=/cid=xxx/` 形式 (旧実装の `/cid/xxx` は誤り。DL-XX 事故)
//   - anchor は上から順に試すフォールバック配列 — DLsite/FANZA 両方入れる (ページ側に片方しか存在しない)
//   - FANZA `.l-areaVariableBoxGroup` は display:table の親を持つので afterend で外に出す
//   - 既存 DOM は一切変更しない (壊さない)
//   - 価格や履歴は doujin-labo の API から取るので DOM スクレイプは不要

(function () {
  const DL = self.DL;
  if (!DL || !DL.renderPanel) return;

  // --- URL → product_id ---
  function extractWorkCode() {
    const href = location.href;
    // DLsite: /product_id/XXnnn (RJ/BJ/VJ/WJ/RE/BR/VR/VE/WE/BE)
    let m = href.match(/\/product_id\/((?:RJ|BJ|VJ|WJ|RE|BR|VR|VE|WE|BE)\d+)/i);
    if (m) return m[1].toUpperCase();
    // FANZA 同人: /=/cid=d_xxx/ (`/cid=` の等号形式が実在。旧実装の `/cid/xxx` は誤り)
    m = href.match(/[/=]cid=(d_[a-z0-9_]+)/i);
    if (m) return m[1].toLowerCase();
    // FANZA 動画: /=/cid=xxxxx/ (d_ で始まらないので同人だけ狙う)
    return null;
  }

  function isTrackablePage() {
    const id = extractWorkCode();
    if (!id) return false;
    // DLsite announce (予約作品) は履歴が無いので静かにスキップ
    if (!id.startsWith("d_") && location.pathname.includes("/announce/")) return false;
    return true;
  }

  // --- タイトル抽出 (パネルヘッダー用。無くても致命的ではない) ---
  function extractTitle() {
    return (
      document.querySelector("#work_name a")?.textContent?.trim() ||
      document.querySelector("h1#work_name")?.textContent?.trim() ||
      document.querySelector(".productTitle__txt")?.textContent?.trim() ||
      document.querySelector("h1.hreview")?.textContent?.trim() ||
      document.querySelector('meta[property="og:title"]')?.getAttribute("content") ||
      document.title
    );
  }

  // --- store label 判定 ---
  function storeLabel(code) {
    return code.startsWith("d_") ? "FANZA" : "DLsite";
  }

  // --- パネル差込アンカー ---
  // 上から順に試す。ページ側に片方しか存在しないので混ぜて OK。
  // dlsite-price-tracker の実測値をそのまま流用 (2026-09 時点)。
  const ANCHORS = [
    // DLsite (優先: 本文カラム全幅が使える位置)
    { selector: "#work_header", position: "afterend" },
    { selector: "#intro-title", position: "beforebegin" },
    { selector: ".work_parts_container", position: "beforebegin" },
    { selector: "#work_parts_container", position: "beforebegin" },
    { selector: ".work_parts_area", position: "beforebegin" },
    { selector: "#work_outline", position: "beforebegin" },
    { selector: "#work_buy_box_wrapper", position: "afterend" },
    { selector: "#work_right", position: "beforeend" },
    // FANZA 同人
    // 重要: .l-areaProductInfo の親は .l-areaVariableBoxGroup (display:table) で、
    //   その中に panel を挿入すると container-type: inline-size の副作用で
    //   2px 幅に潰れて描画されない。.l-areaVariableBoxGroup afterend で外に出す。
    { selector: ".l-areaVariableBoxGroup", position: "afterend" },
    { selector: ".l-areaProductSummary", position: "beforebegin" },
    { selector: ".l-areaProductInfo", position: "afterend" },
    { selector: ".l-areaPromotionBnr", position: "beforebegin" },
    { selector: ".m-productInformation", position: "afterend" },
    { selector: ".l-areaMainColumn", position: "beforeend" },
  ];

  function findAnchor() {
    for (const a of ANCHORS) {
      const el = document.querySelector(a.selector);
      if (el) return { el, position: a.position };
    }
    return null;
  }

  // --- 実際にマウント ---
  let mounted = false;
  function tryMount() {
    if (mounted) return true;
    if (!isTrackablePage()) return false;
    const work_code = extractWorkCode();
    if (!work_code) return false;
    const anchor = findAnchor();
    if (!anchor) return false; // アンカー未出現 (ページがまだ組み上がっていない)
    const panel = DL.renderPanel(
      {
        work_code,
        title: extractTitle(),
        // 現在価格・定価は API 側で解決する (DOM 依存を減らす)
        currentPrice: null,
        listPrice: null,
        offPct: null,
        storeLabel: storeLabel(work_code),
      },
      anchor.el,
      anchor.position === "afterend"    ? "after"
      : anchor.position === "beforebegin" ? "before"
      : anchor.position === "beforeend"   ? "append"
      : anchor.position === "afterbegin"  ? "prepend"
      : "after"
    );
    if (panel) {
      mounted = true;
      return true;
    }
    return false;
  }

  // 初回試行 → 失敗ならページ組み上がりを短時間 poll → それでもダメなら MutationObserver
  function start() {
    if (tryMount()) return;
    // Ajax で描画される DLsite / FANZA の遅延に備えて 200ms x 15 回 (最大 3s) polling
    let tries = 0;
    const poll = setInterval(() => {
      if (tryMount() || ++tries >= 15) clearInterval(poll);
    }, 200);
    // それでも見つからなければ MutationObserver で 30 秒監視して 1 度だけ差し込む
    const observer = new MutationObserver(() => {
      if (tryMount()) observer.disconnect();
    });
    observer.observe(document.body, { childList: true, subtree: true });
    setTimeout(() => observer.disconnect(), 30000);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start, { once: true });
  } else {
    start();
  }
})();
