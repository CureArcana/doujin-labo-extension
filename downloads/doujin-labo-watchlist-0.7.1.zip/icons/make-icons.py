"""拡張アイコン生成 (2026-09-19 v2 更新)。
サイト本体と同じ BrandMark (frontend/public/icon.svg = アイソメトリック 4 層スタック、DL-069 ブランド刷新) を
ImageMagick で 16 / 32 / 48 / 128 PNG に落とし、透過を保持したまま出力する。

依存: ImageMagick (Windows は https://imagemagick.org、Linux は `apt install imagemagick`)。
実行: python make-icons.py

無い環境向けに、`convert` が見つからなければ本番 VPS 経由でも生成可能:
  scp icon.svg lemon@vps:/tmp/brandmark.svg
  ssh lemon@vps 'for s in 16 32 48 128; do convert -background none -density 800 /tmp/brandmark.svg -resize ${s}x${s} /tmp/brandmark-${s}.png; done'
  scp lemon@vps:/tmp/brandmark-*.png .
"""
import shutil
import subprocess
from pathlib import Path

SIZES = (16, 32, 48, 128)


def main():
    here = Path(__file__).parent
    # 2026-09-19 v3 (お父さま「まだ小さい、枠ギリギリまで」): 拡張専用に viewBox 64x64 に絞った SVG を使う。
    # 元 frontend/public/icon.svg は 100x100 (BrandMark 実質 64x64 で余白 36%)。拡張のツールバーは 16px 枠で
    # 余白があると絵が更に小さく見えるので、枠に張り付く flush 版を別 SVG で管理。
    src_svg = here / "brandmark-flush.svg"
    if not src_svg.exists():
        raise SystemExit(f"BrandMark SVG not found: {src_svg}")

    magick = shutil.which("magick") or shutil.which("convert")
    if not magick:
        raise SystemExit(
            "ImageMagick (magick / convert) not found. Install it or run the VPS fallback in the docstring."
        )
    # Windows の `convert.exe` は NTFS 変換ツールで別物。ImageMagick 版か検査する。
    if magick.lower().endswith("convert") or magick.lower().endswith("convert.exe"):
        try:
            probe = subprocess.run([magick, "--version"], capture_output=True, text=True, timeout=5)
            if "ImageMagick" not in (probe.stdout + probe.stderr):
                raise SystemExit(
                    f"'{magick}' is not ImageMagick (Windows NTFS convert.exe). "
                    "Install ImageMagick and rerun, or use the VPS fallback in the docstring."
                )
        except (subprocess.TimeoutExpired, OSError):
            pass

    for size in SIZES:
        out = here / f"icon-{size}.png"
        # -background none で透過、-density 800 で SVG のラスタライズを高解像度化してから -resize で縮小
        subprocess.run(
            [
                magick, "-background", "none", "-density", "800",
                str(src_svg), "-resize", f"{size}x{size}", str(out),
            ],
            check=True,
        )
        print(f"wrote {out} ({size}x{size})")


if __name__ == "__main__":
    main()
