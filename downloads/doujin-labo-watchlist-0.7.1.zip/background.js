// doujin-labo Chrome 拡張 service worker
// - chrome.alarms で 15 分おきに /api/doujin/fav/summary を叩く
// - unread_alert_count に基づいて action badge を更新
// - 差分が増えたら chrome.notifications で通知
// - popup / content から chrome.runtime.sendMessage 経由でも呼び出せる

const API_BASE = "https://doujin-labo.net";
const STORAGE_KEY_DEVICE = "dl_fav_device";
const STORAGE_KEY_STATE = "dl_fav_bg_state"; // { last_unread, last_notified_ids }
const STORAGE_KEY_SITE_LINK = "dl_fav_site_link"; // DL-056: { site_device_id, linked_at }
const ALARM_NAME = "dl-fav-poll";

async function ensureDevice() {
  const store = await chrome.storage.local.get(STORAGE_KEY_DEVICE);
  const existing = store[STORAGE_KEY_DEVICE];
  const body = { ua_hint: "ext-bg" };
  if (existing?.device_id) body.device_id = existing.device_id;
  const res = await fetch(`${API_BASE}/api/doujin/fav/device`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  }).catch(() => null);
  if (!res || !res.ok) return existing?.device_id || null;
  const json = await res.json();
  await chrome.storage.local.set({
    [STORAGE_KEY_DEVICE]: { device_id: json.device_id, group_id: json.group_id, saved_at: Date.now() },
  });
  return json.device_id;
}

async function fetchSummary() {
  const did = await ensureDevice();
  if (!did) return null;
  const r = await fetch(`${API_BASE}/api/doujin/fav/summary`, { headers: { "X-Device-Id": did } }).catch(() => null);
  return r && r.ok ? r.json() : null;
}

async function fetchList() {
  const did = await ensureDevice();
  if (!did) return null;
  const r = await fetch(`${API_BASE}/api/doujin/fav/list`, { headers: { "X-Device-Id": did } }).catch(() => null);
  return r && r.ok ? r.json() : null;
}

async function setBadge(unread) {
  const n = Number(unread) || 0;
  try {
    if (n > 0) {
      // 2026-09-19 お父さま指示「ピンクは見づらい、二桁三桁対応」:
      // ピンク #F34B9F 白文字は Chrome ツールバーの淡い背景で埋もれる → 通知系の王道の赤 #DC2626 + 白文字に。
      // Chrome 110+ は setBadgeTextColor で明示できる (旧版は自動で白/黒コントラストが選ばれる)。
      // 桁数: Chrome バッジは 4 文字まで表示可。1-99 は素の数字、100-999 は 3 桁のまま (フォントが自動縮小)、1000+ は "999+"。
      chrome.action.setBadgeBackgroundColor({ color: "#DC2626" });
      try { chrome.action.setBadgeTextColor({ color: "#FFFFFF" }); } catch (e) { /* Chrome < 110 は自動判定 */ }
      chrome.action.setBadgeText({ text: n > 999 ? "999+" : String(n) });
    } else {
      chrome.action.setBadgeText({ text: "" });
    }
  } catch (e) { /* no-op */ }
}

async function fireNotifications(items) {
  // items: alerts that newly matched (current_price <= threshold and not previously seen)
  for (const it of items.slice(0, 3)) {
    const title = it.work?.title || it.work_code;
    const price = it.current_price != null ? `${Number(it.current_price).toLocaleString()}円` : "";
    const thresh = it.alert_threshold_yen != null ? `${Number(it.alert_threshold_yen).toLocaleString()}円` : "";
    try {
      await chrome.notifications.create(`dl-alert-${it.work_code}-${Date.now()}`, {
        type: "basic",
        iconUrl: chrome.runtime.getURL("icons/icon-128.png"),
        title: "💗 通知価格に到達しました",
        message: `${price}${thresh ? `（設定 ${thresh}以下）` : ""}\n${title}`,
        priority: 1,
      });
    } catch (e) { /* notifications permission may be off */ }
  }
}

async function pollTick() {
  const summary = await fetchSummary();
  if (!summary) return;
  // バッジは「現在アラート到達数」ベース (unread ではなく total hit)。
  // 既読化しても値下げ中の間はずっと数字が出続けるので、他 Chrome 拡張と同じ挙動になる。
  await setBadge(summary.alert_hit_count ?? summary.unread_alert_count ?? 0);
  const st = (await chrome.storage.local.get(STORAGE_KEY_STATE))[STORAGE_KEY_STATE] || { last_unread: 0, last_notified: {} };
  if (summary.unread_alert_count > (st.last_unread || 0)) {
    // fetch list, find items with alert_hit=true not yet notified
    const list = await fetchList();
    const fresh = (list?.items || []).filter(
      (it) => it.alert_hit && !st.last_notified?.[it.work_code + ":" + it.current_price]
    );
    if (fresh.length) {
      await fireNotifications(fresh);
      st.last_notified = st.last_notified || {};
      for (const it of fresh) st.last_notified[it.work_code + ":" + it.current_price] = Date.now();
      // trim map
      const entries = Object.entries(st.last_notified);
      if (entries.length > 200) {
        entries.sort((a, b) => a[1] - b[1]);
        st.last_notified = Object.fromEntries(entries.slice(-200));
      }
    }
  }
  st.last_unread = summary.unread_alert_count;
  await chrome.storage.local.set({ [STORAGE_KEY_STATE]: st });
}

// -------- 更新チェック ----------
// ストア外配布 (zip をデベロッパーモードで読み込む) なので Chrome の自動更新が効かない。
// 配布ページの version.json を 1 日 1 回見て、新しい版があれば popup に帯を出す (popup.js)。
const UPDATE_URL = "https://curearcana.github.io/doujin-labo-extension/version.json";
const STORAGE_KEY_UPDATE = "dl_update"; // { latest, url, checked_at } (新しい版が無ければ latest=null)
const UPDATE_ALARM = "dl-update-check";

function _verCmp(a, b) {
  const pa = String(a).split(".").map((n) => parseInt(n, 10) || 0);
  const pb = String(b).split(".").map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d) return d;
  }
  return 0;
}

async function checkUpdate() {
  const res = await fetch(UPDATE_URL, { cache: "no-store", credentials: "omit" }).catch(() => null);
  if (!res || !res.ok) return;
  const j = await res.json().catch(() => null);
  if (!j?.version) return;
  const newer = _verCmp(j.version, chrome.runtime.getManifest().version) > 0;
  // 帯のリンク先は配布ページに固定する (version.json の中身で任意 URL へ飛ばせないように)
  const url = typeof j.url === "string" && j.url.startsWith("https://curearcana.github.io/") ? j.url : null;
  await chrome.storage.local.set({
    [STORAGE_KEY_UPDATE]: { latest: newer ? String(j.version) : null, url, checked_at: Date.now() },
  });
}

// -------- lifecycle ----------
chrome.runtime.onInstalled.addListener(async () => {
  await ensureDevice();
  await chrome.alarms.create(ALARM_NAME, { periodInMinutes: 5, delayInMinutes: 1 });
  await chrome.alarms.create(UPDATE_ALARM, { periodInMinutes: 60 * 24, delayInMinutes: 2 });
  pollTick();
  checkUpdate();
});

chrome.runtime.onStartup.addListener(async () => {
  await chrome.alarms.create(ALARM_NAME, { periodInMinutes: 5, delayInMinutes: 1 });
  await chrome.alarms.create(UPDATE_ALARM, { periodInMinutes: 60 * 24, delayInMinutes: 2 });
  pollTick();
  checkUpdate();
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM_NAME) pollTick();
  if (alarm.name === UPDATE_ALARM) checkUpdate();
});

// 拡張内での mutation (popup / panel / options が add/patch/remove) を検知して
// バッジをリアルタイム更新する。dl_fav_live_touch が lib/api.js から bump される。
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.dl_fav_live_touch) {
    pollTick();
  }
});

// ------------ content script → background API proxy -------------
// content script (dlsite.com / dmm.co.jp origin) は CORS で doujin-labo.net
// に直 fetch できないため、ここで代行する。extension origin (background /
// popup / options) からの fetch は host_permissions が効いて OPTIONS 不要。

async function _apiFetch(path, options = {}) {
  const url = path.startsWith("http") ? path : `${API_BASE}${path}`;
  try {
    const r = await fetch(url, options);
    if (!r.ok) return { ok: false, status: r.status };
    if (options.responseType === "raw") return { ok: true, status: r.status };
    const j = await r.json().catch(() => null);
    return { ok: true, status: r.status, body: j };
  } catch (e) {
    return { ok: false, status: 0, error: String(e?.message || e) };
  }
}

async function _handleApi(op, params = {}) {
  const did = await ensureDevice();
  if (!did) return null;
  const enc = encodeURIComponent;
  switch (op) {
    case "ensureDevice": {
      return { device_id: did };
    }
    case "list": {
      const r = await _apiFetch(`/api/doujin/fav/list`, { headers: { "X-Device-Id": did } });
      return r.ok ? r.body : null;
    }
    case "summary": {
      const r = await _apiFetch(`/api/doujin/fav/summary`, { headers: { "X-Device-Id": did } });
      return r.ok ? r.body : null;
    }
    case "add": {
      const body = { device_id: did, work_code: params.work_code };
      if (params.added_price != null) body.added_price = Number(params.added_price);
      if (params.alert_threshold_yen != null) body.alert_threshold_yen = Number(params.alert_threshold_yen);
      const r = await _apiFetch(`/api/doujin/fav/add`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body),
      });
      return r.ok ? r.body : null;
    }
    case "patch": {
      const r = await _apiFetch(`/api/doujin/fav/${enc(params.work_code)}`, {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ device_id: did, alert_threshold_yen: params.alert_threshold_yen }),
      });
      return r.ok ? r.body : null;
    }
    case "remove": {
      const r = await _apiFetch(`/api/doujin/fav/${enc(params.work_code)}`, {
        method: "DELETE",
        headers: { "X-Device-Id": did },
        responseType: "raw",
      });
      return r.ok;
    }
    case "markRead": {
      const r = await _apiFetch(`/api/doujin/fav/mark-read`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ device_id: did }),
        responseType: "raw",
      });
      return r.ok;
    }
    case "pairIssue": {
      const r = await _apiFetch(`/api/doujin/fav/pair/issue`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ device_id: did }),
      });
      return r.ok ? r.body : null;
    }
    case "pairRedeem": {
      const r = await _apiFetch(`/api/doujin/fav/pair/redeem`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ device_id: did, code: String(params.code || "").trim().toUpperCase() }),
      });
      return { ok: r.ok, status: r.status, ...(r.body || {}) };
    }
    case "work": {
      const r = await _apiFetch(`/api/doujin/work/${enc(params.work_code)}`);
      return r.ok ? r.body : null;
    }
    default:
      return null;
  }
}

// popup / options ページからのみ呼べる特権操作 (デバイス乗っ取り防止)
// pairRedeem/pairIssue は他人の group 操作に直結するため content script からは弾く。
const _PRIVILEGED_OPS = new Set(["pairIssue", "pairRedeem"]);

function _isTrustedSender(sender) {
  if (!sender || sender.id !== chrome.runtime.id) return false;
  const url = sender.url || "";
  // popup/options ページは chrome-extension://<id>/... で始まる。
  // content script は https://... (dlsite.com / dmm.co.jp) になる。
  return url.startsWith(chrome.runtime.getURL(""));
}

// popup / content からのリクエスト対応
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === "poll_now") {
    pollTick().then(() => sendResponse({ ok: true }));
    return true;
  }
  if (msg?.type === "clear_badge") {
    setBadge(0).then(() => sendResponse({ ok: true }));
    return true;
  }
  if (msg?.type === "ping") {
    sendResponse({ ok: true });
    return false;
  }
  if (msg?.type === "dl:site-device") {
    // 自サイトの content script からのみ受け付ける (他ドメインの content script は manifest 上そもそも無いが念のため)
    const from = sender?.url || "";
    if (sender?.id !== chrome.runtime.id || !from.startsWith("https://doujin-labo.net/")) {
      sendResponse({ ok: false, error: "forbidden" });
      return false;
    }
    linkSiteDevice(msg.device_id).then((res) => sendResponse(res));
    return true;
  }
  if (msg?.type === "dl:api") {
    if (_PRIVILEGED_OPS.has(msg.op) && !_isTrustedSender(sender)) {
      sendResponse({ ok: false, error: "forbidden", status: 403 });
      return false;
    }
    _handleApi(msg.op, msg.params || {}).then((body) => sendResponse(body));
    return true; // async response
  }
});

// DL-056: doujin-labo.net の content script (content/site-sync.js) がサイト側 device_id を送ってくる。
// 拡張の device と /pair/link で同じ group に合流させる (コード入力不要)。
// 同じ site_device_id なら 24h に 1 回だけ叩く (group はサーバー側で丸ごと移動するので基本ずれない)。
async function linkSiteDevice(siteDeviceId) {
  if (!/^[0-9a-f]{32}$/.test(siteDeviceId || "")) return { ok: false };
  const did = await ensureDevice();
  if (!did || did === siteDeviceId) return { ok: !!did, changed: false };
  const st = (await chrome.storage.local.get(STORAGE_KEY_SITE_LINK))[STORAGE_KEY_SITE_LINK];
  const age = Date.now() - (st?.linked_at || 0);
  if (st?.site_device_id === siteDeviceId) {
    if (st.ok !== false && age < 24 * 3600 * 1000) return { ok: true, changed: false, cached: true };
    if (st.ok === false && age < 10 * 60 * 1000) return { ok: false, cached: true }; // 失敗はサーバーを叩かず 10 分待つ (backoff)
  }
  const r = await _apiFetch(`/api/doujin/fav/pair/link`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ device_id: did, other_device_id: siteDeviceId }),
  });
  if (!r.ok) {
    await chrome.storage.local.set({ [STORAGE_KEY_SITE_LINK]: { site_device_id: siteDeviceId, linked_at: Date.now(), ok: false } });
    return { ok: false, status: r.status };
  }
  await chrome.storage.local.set({ [STORAGE_KEY_SITE_LINK]: { site_device_id: siteDeviceId, linked_at: Date.now(), ok: true } });
  if (r.body?.changed) {
    try { chrome.storage.local.set({ dl_fav_live_touch: Date.now() }); } catch (e) {}
    pollTick();
  }
  return { ok: true, changed: !!r.body?.changed, favorites_count: r.body?.favorites_count };
}

// notification クリックで doujin-labo を開く
chrome.notifications.onClicked.addListener((notificationId) => {
  chrome.tabs.create({ url: "https://doujin-labo.net/favorites" });
  chrome.notifications.clear(notificationId);
});
