(function () {
  const DL = self.DL;
  const yen = (n) => (n == null ? "—" : Number(n).toLocaleString() + "円");
  const CAT_LABEL = { comic: "漫画", cg: "CG", voice: "ボイス", movie: "動画", game: "ゲーム", illust: "CG" };
  const STORE_LABEL = { dlsite: "DLsite", fanza: "FANZA" };

  const state = {
    items: [],
    activeStore: "all",
    activeCat: "",       // "" = すべて
    onlyHit: false,
    editingThreshold: null, // 通知価格編集中の work_code (null=非編集)
  };

  const els = {
    list: document.getElementById("pop-list"),
    hitChip: document.getElementById("pop-hit-chip"),
    hitCount: document.getElementById("pop-hit-count"),
    refresh: document.getElementById("pop-refresh"),
    footinfo: document.getElementById("pop-footinfo"),
    tabs: Array.from(document.querySelectorAll(".pop-tab")),
    cats: Array.from(document.querySelectorAll(".pop-cat")),
    onlyHitToggle: document.getElementById("pop-only-hit"),
    counts: {
      all: document.querySelector("[data-count-all]"),
      dlsite: document.querySelector("[data-count-dlsite]"),
      fanza: document.querySelector("[data-count-fanza]"),
    },
  };

  function el(tag, props, ...children) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(props || {})) {
      if (k === "class") e.className = v;
      else if (k === "html") e.innerHTML = v;
      else if (k === "style" && typeof v === "object") Object.assign(e.style, v);
      else if (k.startsWith("on") && typeof v === "function") e.addEventListener(k.slice(2), v);
      else if (v != null && v !== false) e.setAttribute(k, v);
    }
    for (const c of children.flat()) {
      if (c == null || c === false) continue;
      e.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
    }
    return e;
  }

  function itemMatchesStore(it, store) {
    if (store === "all") return true;
    // items.stores から判定 (両ストア持ちの場合はどちらのタブでも表示)
    return (it.stores || []).some((s) => s.site === store);
  }

  function itemMatchesCat(it, cat) {
    if (!cat) return true;
    const c = it.work?.category || "";
    // cg と illust は等価扱い
    if (cat === "cg") return c === "cg" || c === "illust";
    return c === cat;
  }

  function itemMatchesHit(it, onlyHit) {
    return !onlyHit || it.alert_hit;
  }

  // 割引率 → tier クラス (10% 刻み、90%+ は t90)。サイト `.dl-offbar` と同じ配色を購入ボタンに適用する。
  function offTier(p) {
    if (!p || p <= 0) return "";
    if (p >= 90) return " t90";
    return " t" + (Math.floor(p / 10) * 10);
  }

  function renderStoreRow(store, item) {
    const isBest = store.site === item.best_site && (item.stores || []).length > 1;
    // /go/{site}/{code} 経由。doujin-labo.net の 302 route が dlaf / al アフィ URL を組んで転送する
    // (拡張が直接 dlaf を組むより規約整合性が高い + env / 承認状態の切替に自動追随)
    const goUrl = `https://doujin-labo.net/go/${store.site}/${encodeURIComponent(store.work_code)}`;
    const tierCls = offTier(store.off_pct);
    const goBtn = el("a", {
      class: "pop-store-go" + tierCls,
      href: goUrl,
      target: "_blank",
      rel: "noopener sponsored",
      title: `${STORE_LABEL[store.site] || store.site} で購入ページを開く`,
      onclick: (e) => {
        // カード全体の onclick (作品詳細ページを開く) が発火しないように止める
        e.stopPropagation();
        // popup 内 a[target=_blank] は Chrome が新規タブを開くが、popup 側は残る。
        // 明示 tabs.create + close で他の card クリックと挙動を揃える
        e.preventDefault();
        chrome.tabs.create({ url: goUrl });
        window.close();
      },
    });
    // 「購入」ボタン: テキストを大きく + 矢印も拡大。割引率で背景色をサイトと揃える (tierCls)。
    goBtn.innerHTML = '<span class="pop-store-go-label">購入</span><svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8h9"/><path d="M9 4l5 4-5 4"/></svg>';

    // 列位置を固定: [chip] [price 右寄せ] [was] [off%] [購入]
    // - 割引無しでも was/off セルは空で描画して列を保持 → 上下行で ¥ と % が縦にピタリ揃う
    // - 「最安」は行の背景色 (.best) と価格文字色で表現 → 中央列が動かない
    const wasCell = store.list_price && store.list_price > store.price
      ? el("span", { class: "pop-store-was" }, yen(store.list_price))
      : el("span", { class: "pop-store-was empty" });
    const offCell = store.off_pct > 0
      ? el("span", { class: "pop-store-off" }, `-${store.off_pct}%`)
      : el("span", { class: "pop-store-off empty" });

    const chip = el("span", { class: `pop-store-chip ${store.site}` }, STORE_LABEL[store.site] || store.site);
    if (isBest) chip.setAttribute("title", "最安");

    const row = el("div", { class: "pop-store-row" + (isBest ? " best" : "") },
      chip,
      el("span", { class: "pop-store-price" }, yen(store.price)),
      wasCell,
      offCell,
      goBtn,
    );
    return row;
  }

  // 片方のストアが取扱なしの時のプレースホルダ行 (2 行ぶんの高さを保証)
  function renderMissingStoreRow(site) {
    return el("div", { class: "pop-store-row missing" },
      el("span", { class: `pop-store-chip ${site} muted` }, STORE_LABEL[site] || site),
      el("span", { class: "pop-store-price muted" }, "取扱なし"),
      el("span", { class: "pop-store-was empty" }),
      el("span", { class: "pop-store-off empty" }),
      el("span", { class: "pop-store-go empty" }),
    );
  }

  // 通知価格エディタ: サークル名行に埋め込むインライン入力。
  // 保存すると DL.apiPatch → 同一 group_id の他端末は次回 fetch で自動反映。
  // Enter=保存 / Escape=キャンセル。
  function renderThresholdEditor(it) {
    const current = it.alert_threshold_yen ?? "";
    const input = el("input", {
      type: "number",
      min: "0",
      step: "10",
      value: current === "" ? "" : String(current),
      placeholder: "円",
      class: "pop-th-input",
      onclick: (e) => e.stopPropagation(),
      onkeydown: (e) => {
        e.stopPropagation();
        if (e.key === "Enter") { e.preventDefault(); saveThreshold(it, input.value); }
        else if (e.key === "Escape") { e.preventDefault(); cancelThresholdEdit(); }
      },
    });
    const save = el("button", {
      class: "pop-th-save",
      title: "保存 (Enter)",
      onclick: (e) => { e.stopPropagation(); saveThreshold(it, input.value); },
    });
    save.innerHTML = '<svg width="10" height="10" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M3 8l3.5 3.5L13 4.5"/></svg>';
    const cancel = el("button", {
      class: "pop-th-cancel",
      title: "キャンセル (Esc)",
      onclick: (e) => { e.stopPropagation(); cancelThresholdEdit(); },
    });
    cancel.innerHTML = '<svg width="10" height="10" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><path d="M4 4l8 8M12 4l-8 8"/></svg>';
    const wrap = el("div", {
      class: "pop-th-editor",
      onclick: (e) => e.stopPropagation(),
    },
      el("span", { class: "pop-th-editor-label" }, "通知価格 ¥"),
      input,
      save,
      cancel,
    );
    // マウント後にフォーカス + 全選択で即入力できる
    setTimeout(() => { try { input.focus(); input.select(); } catch (e) {} }, 0);
    return wrap;
  }

  async function saveThreshold(it, rawValue) {
    const trimmed = String(rawValue ?? "").trim();
    if (trimmed === "") {
      cancelThresholdEdit();
      return;
    }
    const num = Number(trimmed);
    if (!Number.isFinite(num) || num < 0) {
      // 不正値: そのまま編集を続ける (ユーザーに再入力を促す)
      return;
    }
    const rounded = Math.round(num);
    // 楽観的更新: UI を先に更新してから API 送信 (API 完了時に reload で正)
    const item = state.items.find((x) => x.work_code === it.work_code);
    if (item) {
      item.alert_threshold_yen = rounded;
      if (item.current_price != null) item.alert_hit = item.current_price <= rounded;
    }
    state.editingThreshold = null;
    render();
    // apiPatch → 成功時に _touchLive → 他 Chrome コンテキストは onLiveChange で reload
    // → 同一 group_id の他端末 (スマホ / PC ブラウザ) は次のポーリングで反映
    const res = await DL.apiPatch(it.work_code, rounded);
    if (!res) {
      // 失敗: 次の reload でサーバー真値に戻す
      els.footinfo.textContent = "通知価格の更新に失敗しました";
    }
    // fresh な alert_hit 状態を取り直す
    reload();
  }

  function cancelThresholdEdit() {
    state.editingThreshold = null;
    render();
  }

  function beginThresholdEdit(work_code) {
    state.editingThreshold = work_code;
    render();
  }

  function renderCard(it) {
    const w = it.work || {};
    const isHit = !!it.alert_hit;
    const detailUrl = `https://doujin-labo.net/w/${encodeURIComponent(it.work_code)}`;
    const thumbUrl = w.thumbnail_url;
    const catLabel = CAT_LABEL[w.category] || null;

    const card = el("div", {
      class: "pop-card" + (isHit ? " is-hit" : ""),
      onclick: (e) => {
        if (e.target.closest(".pop-remove")) return;
        chrome.tabs.create({ url: detailUrl });
        window.close();
      },
    });

    const thumb = el("span", { class: "pop-thumb" });
    if (thumbUrl) thumb.appendChild(el("img", { src: thumbUrl, alt: "", loading: "lazy" }));
    else thumb.innerHTML = '<span class="ph"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="3" y="4" width="18" height="16"></rect><path d="M3 16l5-4 4 3 3-2 6 4"></path><circle cx="8.5" cy="9" r="1.4"></circle></svg></span>';

    // 通知到達時は thumb 底部にピンクストリップで表現 (以前は body の中に別行があり縦幅を食っていた)
    // クリックで通知価格エディタを開く。編集中はストリップ位置にエディタを埋める (横に飛ばない)
    const editingThis = state.editingThreshold === it.work_code;
    const showHitStrip = isHit && it.alert_threshold_yen != null;
    if (showHitStrip && !editingThis) {
      const strip = el("div", {
        class: "pop-thumb-strip",
        title: "通知価格を編集",
        onclick: (e) => { e.stopPropagation(); beginThresholdEdit(it.work_code); },
      },
        el("span", { class: "pop-thumb-strip-label" }, `⚡ 通知 ${yen(it.alert_threshold_yen)}`),
        el("span", { class: "pop-thumb-strip-status" }, "到達"),
      );
      thumb.appendChild(strip);
    } else if (showHitStrip && editingThis) {
      // 到達中の編集はストリップ位置に置く (メタ行へ飛ばさない)
      thumb.appendChild(el("div", {
        class: "pop-thumb-strip is-editing",
        onclick: (e) => e.stopPropagation(),
      }, renderThresholdEditor(it)));
    }
    card.appendChild(thumb);

    const body = el("div", { class: "pop-body" });

    // タイトル (カテゴリ chip をインラインで先頭に埋める → 独立した eyebrow 行を廃止)
    const titleEl = el("div", { class: "pop-title" });
    if (catLabel) titleEl.appendChild(el("span", { class: "pop-cat-chip" }, catLabel));
    titleEl.appendChild(document.createTextNode(w.title || it.work_code));
    body.appendChild(titleEl);

    // メタ行: サークル名 + [通知価格タグ / 設定ボタン / エディタ]
    // - 編集中: インラインエディタ
    // - 未設定: 「+ 通知価格」ボタン
    // - 未到達: 現在値ピル (クリックで編集)
    // - 到達済み: thumb strip 側で表示 (クリックで編集)
    const metaLine = el("div", { class: "pop-meta-line" });
    metaLine.appendChild(el("span", { class: "pop-circle" }, w.circle_name || ""));

    if (editingThis && !showHitStrip) {
      // 未設定 / 未到達の編集はメタ行 (元のボタン / ピルの位置) に埋める
      metaLine.appendChild(renderThresholdEditor(it));
    } else if (it.alert_threshold_yen == null) {
      // 未設定: 設定ボタン (すべての作品に必ず出る)
      const setBtn = el("button", {
        class: "pop-threshold-set",
        title: "通知価格を設定",
        onclick: (e) => { e.stopPropagation(); beginThresholdEdit(it.work_code); },
      }, "＋ 通知価格");
      metaLine.appendChild(setBtn);
    } else if (!isHit) {
      // 未到達: 現在値ピル (クリックで編集)
      const cur = it.current_price;
      const th = it.alert_threshold_yen;
      const rest = cur != null ? Math.max(0, cur - th) : null;
      const label = rest != null && rest > 0
        ? `${yen(th)} まで あと ${yen(rest)}`
        : `${yen(th)}`;
      const pill = el("button", {
        class: "pop-threshold-mini",
        title: "通知価格を編集",
        onclick: (e) => { e.stopPropagation(); beginThresholdEdit(it.work_code); },
      }, label);
      metaLine.appendChild(pill);
    }
    body.appendChild(metaLine);

    // 価格行群: DLsite / FANZA を常に 2 行描画。取扱が無いストアは "取扱なし" プレースホルダで
    // 縦幅を統一 (カード同士の高さが揃う)。
    const prices = el("div", { class: "pop-prices" });
    const storesByKey = Object.fromEntries((it.stores || []).map((s) => [s.site, s]));
    for (const site of ["dlsite", "fanza"]) {
      const store = storesByKey[site];
      prices.appendChild(store ? renderStoreRow(store, it) : renderMissingStoreRow(site));
    }
    body.appendChild(prices);

    card.appendChild(body);

    const remove = el("button", {
      class: "pop-remove",
      title: "お気に入りから外す",
      onclick: async (e) => {
        e.stopPropagation();
        if (!confirm("お気に入りから外しますか？")) return;
        remove.disabled = true;
        const ok = await DL.apiRemove(it.work_code);
        if (ok) {
          state.items = state.items.filter((x) => x.work_code !== it.work_code);
          render();
        }
      },
    });
    remove.innerHTML = '<svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 4l8 8M12 4l-8 8"></path></svg><span>解除</span>';
    card.appendChild(remove);

    return card;
  }

  function render() {
    const items = state.items;
    // counts by store (両ストア持ちは両方カウント)
    const counts = { all: items.length, dlsite: 0, fanza: 0 };
    for (const it of items) {
      const stores = new Set((it.stores || []).map((s) => s.site));
      if (stores.has("dlsite")) counts.dlsite++;
      if (stores.has("fanza")) counts.fanza++;
    }
    els.counts.all.textContent = counts.all;
    els.counts.dlsite.textContent = counts.dlsite;
    els.counts.fanza.textContent = counts.fanza;

    const hits = items.filter((i) => i.alert_hit).length;
    if (hits > 0) {
      els.hitChip.hidden = false;
      els.hitCount.textContent = String(hits);
    } else {
      els.hitChip.hidden = true;
    }

    const filtered = items
      .filter((i) => itemMatchesStore(i, state.activeStore))
      .filter((i) => itemMatchesCat(i, state.activeCat))
      .filter((i) => itemMatchesHit(i, state.onlyHit));
    filtered.sort((a, b) => {
      if (!!b.alert_hit - !!a.alert_hit !== 0) return !!b.alert_hit - !!a.alert_hit;
      return (b.added_at || "").localeCompare(a.added_at || "");
    });

    els.list.innerHTML = "";
    if (!filtered.length) {
      const empty = el("div", { class: "pop-empty" });
      empty.innerHTML = `
        <div class="pop-empty-heart">♡</div>
        <div class="pop-empty-title">${items.length === 0 ? "お気に入りはまだありません" : "該当する作品がありません"}</div>
        <div class="pop-empty-sub">${items.length === 0
          ? "DLsite / FANZA の作品ページを開くと、パネルから追加できます。"
          : "フィルタを切り替えてみてください。"}</div>
      `;
      els.list.appendChild(empty);
    } else {
      for (const it of filtered) els.list.appendChild(renderCard(it));
    }

    els.footinfo.textContent = `${filtered.length} / ${items.length} 件表示（DLsite ${counts.dlsite} ／ FANZA ${counts.fanza}）`;
  }

  // 起動時: chrome.storage の snapshot を即描画してから API 取得へ。
  // popup は開くたび新プロセスなので、これが無いと空 → API 待ち → 表示となり体感が遅い。
  async function primeFromCache() {
    try {
      const snap = await DL.getSnapshot();
      if (snap?.items?.length) {
        state.items = snap.items;
        render();
        const ts = snap.updated_at ? new Date(snap.updated_at) : null;
        els.footinfo.textContent = ts
          ? `キャッシュ表示中 (${ts.toLocaleTimeString("ja-JP", { hour: "2-digit", minute: "2-digit" })}) ・ 更新中…`
          : "更新中…";
        return true;
      }
    } catch (e) { /* noop */ }
    return false;
  }

  async function reload() {
    // 編集中は skip: 入力中の値がリロードで潰れないように (保存時は自分で明示的に呼ぶ)
    if (state.editingThreshold != null) return;
    const hadCache = state.items.length > 0;
    if (!hadCache) els.footinfo.textContent = "読み込み中…";
    const j = await DL.apiList();
    if (!j) {
      els.footinfo.textContent = hadCache
        ? "更新できませんでした（表示はキャッシュ）"
        : "取得できませんでした";
      return;
    }
    state.items = j.items || [];
    render();
    // 次回オープン時の即時表示用にスナップショット保存
    try { DL.setSnapshot({ items: state.items }); } catch (e) {}
    DL.apiMarkRead();
    // バッジ / アイコン色は background.js 側で alert_hit_count を再取得して反映する
    try { chrome.runtime.sendMessage({ type: "poll_now" }); } catch (e) { /* noop */ }
  }

  // wire tabs
  for (const btn of els.tabs) {
    btn.addEventListener("click", () => {
      for (const b of els.tabs) b.classList.toggle("is-on", b === btn);
      state.activeStore = btn.dataset.store;
      render();
    });
  }
  for (const btn of els.cats) {
    btn.addEventListener("click", () => {
      for (const b of els.cats) b.classList.toggle("is-on", b === btn);
      state.activeCat = btn.dataset.cat;
      render();
    });
  }
  els.onlyHitToggle.addEventListener("change", (e) => {
    state.onlyHit = e.target.checked;
    render();
  });
  els.refresh.addEventListener("click", async () => {
    els.refresh.disabled = true;
    try { chrome.runtime.sendMessage({ type: "poll_now" }); } catch (e) { /* noop */ }
    await reload();
    els.refresh.disabled = false;
  });

  // -------- live sync --------
  // 1) 別の extension context (in-page panel / options / background poll) が
  //    mutation を起こしたら chrome.storage.onChanged で即 reload。
  // 2) doujin-labo.net web page からの編集は storage を触らないため、10s poll で拾う。
  // 3) 画面表示に戻ってきた瞬間 (visibilitychange, focus) にも reload。
  DL.onLiveChange(() => { reload(); });
  const pollTimer = setInterval(() => { reload(); }, 10000);
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") reload();
  });
  window.addEventListener("focus", () => { reload(); });
  window.addEventListener("beforeunload", () => { clearInterval(pollTimer); });

  // キャッシュ即描画 → 裏で API 取得。ネットが遅くても空白が出ない。
  primeFromCache().finally(reload);
})();

// 更新の案内: background の checkUpdate が見つけた新しい版を帯で知らせる (ストア外配布は自動更新されない)
(function () {
  const bar = document.getElementById("pop-update");
  if (!bar) return;
  try {
    chrome.storage.local.get("dl_update", (v) => {
      const u = v?.dl_update;
      if (!u?.latest || !u.url) return;
      bar.textContent = `新しい版 v${u.latest} があります (いま v${chrome.runtime.getManifest().version}) → 更新方法を見る`;
      bar.href = u.url;
      bar.hidden = false;
    });
  } catch (e) { /* noop */ }
})();
