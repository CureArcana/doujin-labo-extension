// doujin-labo Chrome 拡張 - in-page パネルレンダラ (v0.5.0: 拡張内ネイティブ描画・コンパクト版)
//
// 構造 (上から):
//   .dl-p-head  : 「価格・割引の推移」+ 作品名 + 過去最安チップ + 期間タブ (1ヶ月 / 3ヶ月 / 全期間)
//   .dl-p-main  : 左 = 統計 1 行 + チャート (クロスヘア付き) + 凡例 / 右 = 他ストアの価格 + 購入 CTA
//   .dl-p-bar   : フォローする / 最安値で通知 / (登録済: 通知価格 入力・更新・解除) / 最安値作品 / ウォッチリスト
//
// 2026-09-29 まで iframe (doujin-labo.net/w/{id}/embed) に描画を任せていたが、
//   - カーソルオーバーの縦横クロスヘア
//   - 無駄な余白の削減 (旧: iframe 300px + バー ≒ 350px → 新: ≒ 270px)
//   - 「最安値で通知」(通期最安を通知価格として自動保存)
// を入れるため拡張側で描くようにした。データは /api/doujin/work/{id} (background 経由) から取る。

(function () {
  const DL = self.DL;
  if (!DL || !DL.chart) return;
  const C = DL.chart;
  const yen = C.yen;

  function el(tag, props, ...children) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(props || {})) {
      if (k === "class") e.className = v;
      else if (k === "html") e.innerHTML = v;
      else if (k === "style" && typeof v === "object") Object.assign(e.style, v);
      else if (k.startsWith("on") && typeof v === "function") e.addEventListener(k.slice(2), v);
      else if (v != null && v !== false) e.setAttribute(k, v);
    }
    for (const c of children.flat()) {
      if (c == null || c === false) continue;
      e.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
    }
    return e;
  }

  const ICON = {
    bell: '<svg width="13" height="13" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M5 8a5 5 0 0110 0c0 3.2 1 4.5 1.5 5H3.5C4 12.5 5 11.2 5 8z"/><path d="M8 16a2 2 0 004 0"/></svg>',
    heart: '<svg width="13" height="13" viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M10 17s-6.5-4.2-6.5-9A3.5 3.5 0 0110 6a3.5 3.5 0 016.5 2c0 4.8-6.5 9-6.5 9z"/></svg>',
    low: '<svg width="10" height="10" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M8 2v9"/><path d="M4.5 7.5L8 11l3.5-3.5"/><path d="M3 14h10"/></svg>',
    down: '<svg width="10" height="10" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"><path d="M8 3v9"/><path d="M4 8l4 4 4-4"/></svg>',
    list: '<svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:-2px;margin-right:4px"><path d="M2 4l4 4-4 4"/><path d="M6 8h8"/><path d="M12 4l2 4-2 4"/></svg>',
    check: '<svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M3 8.5l3 3 7-7"/></svg>',
    mark: '<svg width="16" height="16" viewBox="0 0 20 20" fill="none"><rect x="2" y="2" width="16" height="16" rx="3" fill="#F34B9F"/><path d="M5 13l3-4 2.5 3 2-2.5L15 13" stroke="#fff" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" fill="none"/></svg>',
  };

  function buildPanel(ctx) {
    const onStore = String(ctx.work_code).toLowerCase().startsWith("d_") ? "fanza" : "dlsite";
    const panel = el("div", { id: "dl-panel" });

    // ---------- head ----------
    let periodKey = "y1";  // 2026-09-30 お父さま指示: 既定は 1年 (観測がそれより短ければ実質全期間)
    let sel = null;        // 表示範囲 {from, to}。ブラシでドラッグすると periodKey=null の任意範囲になる
    function syncTabs() {
      for (const b of tabBtns) b.classList.toggle("on", b.getAttribute("data-key") === periodKey);
    }
    const lowChip = el("span", { class: "dl-p-chip-low", style: { display: "none" }, html: ICON.low + "過去最安" });
    const tabBtns = C.PERIODS.map((p) =>
      el("button", {
        type: "button",
        class: "dl-p-tab" + (p.key === periodKey ? " on" : ""),
        "data-key": p.key,
        onclick: () => {
          periodKey = p.key;
          if (model && !model.empty) sel = C.periodRange(model, p.key);
          syncTabs();
          redraw();
        },
      }, p.label)
    );
    const head = el("div", { class: "dl-p-head" },
      el("span", { class: "dl-p-mark", html: ICON.mark }),
      el("span", { class: "dl-p-brand" }, "価格・割引の推移"),
      el("span", { class: "dl-p-title", title: ctx.title || "" }, ctx.title || ""),
      lowChip,
      el("span", { class: "dl-p-spacer" }),
      el("span", { class: "dl-p-tabs" }, tabBtns),
    );
    panel.appendChild(head);

    // ---------- main ----------
    const stats = el("div", { class: "dl-p-stats" });
    const chartBox = el("div", { class: "dl-p-chart" });
    const brushBox = el("div", { class: "dl-p-brushbox" });  // 期間ブラシ (2026-09-30)
    const legend = el("div", { class: "dl-p-legend" });
    const side = el("div", { class: "dl-p-side" });
    const main = el("div", { class: "dl-p-main" },
      el("div", { class: "dl-p-left" }, stats, chartBox, brushBox, legend),
      side,
    );
    panel.appendChild(main);

    // ---------- action bar ----------
    const bar = el("div", { class: "dl-p-bar" });
    const statusChip = el("span", { class: "dl-p-bar-status" }, "読み込み中…");
    const followBtn = el("button", { class: "dl-p-btn dl-p-btn-primary", type: "button", style: { display: "none" }, title: "ウォッチリストに追加 (通知価格は後から設定できます)" },
      el("span", { html: ICON.heart }), "フォローする");
    const lowestBtn = el("button", { class: "dl-p-btn dl-p-btn-lowest", type: "button", style: { display: "none" } },
      el("span", { html: ICON.bell }), el("span", { class: "dl-p-lowest-label" }, "最安値で通知"), el("span", { class: "dl-p-lowest-sub" }, ""));
    const thresholdInput = el("input", {
      type: "number", min: "0", step: "10", placeholder: "円", inputmode: "numeric",
      class: "dl-p-th-input", style: { display: "none" },
    });
    const thresholdLabel = el("span", { class: "dl-p-th-label", style: { display: "none" } }, "円以下で通知");
    const saveBtn = el("button", { class: "dl-p-btn dl-p-btn-ghost", type: "button", style: { display: "none" } }, "更新");
    const removeBtn = el("button", { class: "dl-p-btn dl-p-btn-ghost-red", type: "button", style: { display: "none" } }, "解除");
    const lowestLink = el("a", {
      class: "dl-p-listlink dl-p-lowest", href: "https://doujin-labo.net/r/lowest", target: "_blank", rel: "noopener",
      title: "本日、過去最安値を更新した作品", html: ICON.list + "最安値作品を見る",
    });
    const openListLink = el("a", { class: "dl-p-listlink", href: "https://doujin-labo.net/favorites", target: "_blank", rel: "noopener" }, "ウォッチリストを開く →");
    bar.append(statusChip, followBtn, lowestBtn, thresholdInput, thresholdLabel, saveBtn, removeBtn,
      el("span", { class: "dl-p-bar-spacer" }), lowestLink, openListLink);
    panel.appendChild(bar);

    // ---------- state ----------
    let model = null;
    let view = null;
    let workData = null;
    let registered = false;
    let currentThreshold = null;
    let currentPrice = null;   // 表示用 (model.currentPrice 優先、無ければ list の current_price)
    let allTimeMin = null;     // 通期最安 (「最安値で通知」の通知価格)
    let registeredCode = ctx.work_code; // cross_ids 経由で自作品コードと異なる可能性

    // ---------- chart / stats ----------
    function statCell(label, value, opts = {}) {
      const cell = el("div", { class: "dl-p-stat" + (opts.accent ? " accent" : "") },
        el("span", { class: "dl-p-stat-label" + (opts.accent ? " accent" : "") }, label),
        el("span", { class: "dl-p-stat-val" + (opts.strike ? " strike" : "") + (opts.strong ? " strong" : "") }, value),
      );
      if (opts.note) cell.appendChild(el("span", { class: "dl-p-stat-note" }, opts.note));
      return cell;
    }

    function renderStats() {
      stats.innerHTML = "";
      if (!model || model.empty || !view) return;
      const signal = view.isAllTimeLow
        ? el("span", { class: "dl-p-signal", html: ICON.low + "過去最安" })
        : view.off > 0
          ? el("span", { class: "dl-p-signal", html: ICON.down + "値下がり中" })
          : el("span", { class: "dl-p-signal muted" }, "値動きなし");
      const now = el("div", { class: "dl-p-stat dl-p-stat-now" },
        signal,
        el("span", { class: "dl-p-now" }, Number(model.currentPrice ?? 0).toLocaleString(), el("span", null, "円")),
        view.off > 0 ? el("span", { class: "dl-p-off" }, `${view.off}%OFF`) : null,
      );
      const periodIsNow = view.periodMin != null && view.periodMin === model.currentPrice;
      stats.append(
        now,
        statCell("定価", yen(model.listPrice), { strike: true }),
        statCell("期間最安", yen(view.periodMin), { strong: true, accent: periodIsNow, note: periodIsNow ? "いまが最安" : null }),
        statCell("通期最安", yen(model.allTimeMin), { strong: true }),
        statCell("前回最安", yen(model.priorMin), { strong: true }),
      );
      lowChip.style.display = view.isAllTimeLow ? "inline-flex" : "none";
    }

    function renderLegend() {
      legend.innerHTML = "";
      if (!model || model.empty || !view) return;
      for (const s of Object.keys(view.seriesBySite)) {
        const st = C.SITE[s] || { color: "#111", label: s };
        legend.appendChild(el("span", { class: "k" }, el("span", { class: "k-line", style: { background: st.color } }), st.label));
      }
      legend.appendChild(el("span", { class: "k" }, el("span", { class: "k-dash" }), "定価"));
      legend.appendChild(el("span", { class: "dl-p-spacer" }));
      const n = Object.values(view.seriesBySite)[0]?.length || 0;
      legend.appendChild(el("span", { class: "dl-p-legend-note" },
        `${n}日分 ・ 計測 ${C.fmtDate(model.observedFrom)} 〜 ${C.fmtDate(model.observedTo)} ・ 日次観測の参考値`));
    }

    function renderSide() {
      side.innerHTML = "";
      if (!model || model.empty) { side.style.display = "none"; return; }
      side.style.display = "";
      const data = workData || {};
      const pidStr = String(data.product_id || ctx.work_code || "");
      const dlsiteId = data.dlsite_product_id || (pidStr.toLowerCase().startsWith("d_") ? null : pidStr);
      const fanzaId = data.fanza_product_id || (pidStr.toLowerCase().startsWith("d_") ? pidStr : null);
      // 全リンクは doujin-labo.net /go/{site}/{code} 経由 (アフィリエイト付与 + click 統計)
      const goHref = (site, code) => (code ? `https://doujin-labo.net/go/${site}/${encodeURIComponent(code)}` : null);
      const rows = ["dlsite", "fanza"].map((s) => ({
        site: s, price: model.currentBySite?.[s] ?? null,
        url: goHref(s, s === "dlsite" ? dlsiteId : fanzaId),
        isKnown: (s === "dlsite" ? dlsiteId : fanzaId) != null,
      }));
      const priced = rows.filter((r) => r.price != null);
      const minPrice = priced.length ? Math.min(...priced.map((r) => r.price)) : null;
      const maxPrice = priced.length ? Math.max(...priced.map((r) => r.price)) : null;
      const saveYen = priced.length >= 2 ? maxPrice - minPrice : 0;
      const otherSite = onStore === "dlsite" ? "fanza" : "dlsite";
      const ctaRow = rows.find((r) => r.site === otherSite && r.url) || rows.find((r) => r.url);

      side.appendChild(el("div", { class: "dl-p-side-head" }, "他ストアの価格"));
      const list = el("div", { class: "dl-p-side-rows" });
      for (const r of rows) {
        const st = C.SITE[r.site];
        const isBest = r.price != null && r.price === minPrice && priced.length >= 2;
        const inner = [
          el("span", { class: "dl-p-side-chip", style: { background: st.color } }, st.label),
          el("span", { class: "dl-p-side-price" }, r.price != null ? yen(r.price) : (r.isKnown ? "—" : "取扱なし")),
          isBest ? el("span", { class: "dl-p-side-best" }, "最安") : null,
        ];
        list.appendChild(r.url
          ? el("a", { class: "dl-p-side-row link" + (isBest ? " best" : ""), href: r.url, target: "_blank", rel: "sponsored noopener" }, inner)
          : el("div", { class: "dl-p-side-row" + (isBest ? " best" : "") }, inner));
      }
      side.appendChild(list);
      if (saveYen > 0) side.appendChild(el("div", { class: "dl-p-side-save" }, el("b", null, yen(saveYen)), " お得"));
      if (ctaRow?.url) {
        side.appendChild(el("a", {
          class: "dl-p-side-cta", href: ctaRow.url, target: "_blank", rel: "sponsored noopener",
          style: { background: C.SITE[ctaRow.site].color },
        }, `${C.SITE[ctaRow.site].label} で買う →`));
      }
    }

    let raf = 0;
    let brushCtl = null;
    function redraw() {
      if (!model || model.empty) return;
      if (!sel) sel = C.periodRange(model, periodKey || "y1");
      view = C.buildViewRange(model, sel.from, sel.to);
      renderStats();
      renderLegend();
      if (brushCtl) brushCtl.set(sel.from, sel.to);
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => C.render(chartBox, { view, model, focusSite: onStore }));
    }

    async function loadWork() {
      chartBox.innerHTML = "";
      chartBox.appendChild(el("div", { class: "dl-p-empty" }, "価格履歴を読み込み中…"));
      workData = await DL.apiWork(ctx.work_code);
      model = C.buildModel(workData);
      if (!workData || model.empty) {
        chartBox.innerHTML = "";
        chartBox.appendChild(el("div", { class: "dl-p-empty" },
          workData ? "価格履歴データがまだ十分にありません" : "価格履歴データを取得できませんでした"));
        stats.innerHTML = "";
        legend.innerHTML = "";
        side.style.display = "none";
      } else {
        if (model.currentPrice != null) currentPrice = model.currentPrice;
        allTimeMin = model.allTimeMin;
        sel = C.periodRange(model, periodKey);
        // 期間ブラシ: ドラッグ中は onChange が rAF ごとに来るので redraw で本チャートが追従する
        brushCtl = C.brush(brushBox, {
          model,
          onChange: (from, to) => {
            sel = { from, to };
            if (periodKey !== null) { periodKey = null; syncTabs(); }
            redraw();
          },
        });
        brushCtl.render();
        renderSide();
        redraw();
      }
      updateBar();
    }

    // 幅が変わったら描き直す (SVG は container 幅で 1:1 に組んでいる)
    let lastW = 0;
    const ro = new ResizeObserver(() => {
      const w = Math.floor(chartBox.clientWidth);
      if (w && Math.abs(w - lastW) > 4) {
        lastW = w;
        if (brushCtl) brushCtl.render();
        redraw();
      }
    });
    ro.observe(chartBox);

    // ---------- action bar state ----------
    function updateBar() {
      const show = (node, on, disp = "inline-flex") => { node.style.display = on ? disp : "none"; };
      if (registered) {
        statusChip.textContent = currentPrice != null ? `登録中・現在 ${yen(currentPrice)}` : "登録中";
        show(followBtn, false);
        thresholdInput.value = currentThreshold ?? "";
        show(thresholdInput, true); show(thresholdLabel, true); show(saveBtn, true); show(removeBtn, true);
      } else {
        statusChip.textContent = currentPrice != null ? `現在 ${yen(currentPrice)}` : "";
        show(followBtn, true);
        show(thresholdInput, false); show(thresholdLabel, false); show(saveBtn, false); show(removeBtn, false);
      }
      statusChip.style.display = statusChip.textContent ? "inline-flex" : "none";
      // 最安値で通知: 通期最安が分かっている時だけ
      if (allTimeMin != null) {
        show(lowestBtn, true);
        const already = registered && currentThreshold != null && Number(currentThreshold) === Number(allTimeMin);
        lowestBtn.classList.toggle("done", already);
        lowestBtn.disabled = already;
        lowestBtn.querySelector(".dl-p-lowest-label").textContent = already ? "最安値で通知中" : "最安値で通知";
        lowestBtn.querySelector(".dl-p-lowest-sub").textContent = yen(allTimeMin);
        lowestBtn.title = already
          ? `通期最安 ${yen(allTimeMin)} 以下になったら通知します`
          : `通期最安 ${yen(allTimeMin)} を通知価格として保存します`;
      } else {
        show(lowestBtn, false);
      }
    }
    function setLoading() {
      statusChip.textContent = "読み込み中…";
      statusChip.style.display = "inline-flex";
      for (const n of [followBtn, lowestBtn, thresholdInput, thresholdLabel, saveBtn, removeBtn]) n.style.display = "none";
    }

    function applyAddResult(res) {
      if (res.was_dup) {
        registeredCode = res.existing_work_code;
        statusChip.textContent = `別ストア (${res.existing_work_code}) で登録済・両ストアを監視中`;
      } else {
        registeredCode = res.work_code || ctx.work_code;
      }
      registered = true;
      currentThreshold = res.alert_threshold_yen ?? null;
    }

    // 楽観更新 (2026-09-30 お父さま「押してから切り替わるまでラグがある」):
    // API (content script → background → doujin-labo.net) の往復を待たず、押した瞬間に表示を確定形へ
    // 切り替え、裏で保存する。失敗したら元に戻して alert。走行中は hydrate (30s poll / live sync) が
    // 古い一覧で上書きしないよう mutating で止める。
    let mutating = 0;

    function snapshotState() {
      return { registered, currentThreshold, registeredCode };
    }
    function restoreState(s) {
      registered = s.registered;
      currentThreshold = s.currentThreshold;
      registeredCode = s.registeredCode;
    }

    // フォローする: 通知価格は聞かずに即追加 (doujin-labo.net の ♡ と同じ挙動)
    async function doFollow() {
      if (mutating) return;
      const prev = snapshotState();
      registered = true;            // 楽観更新: 即「登録中」表示へ
      updateBar();
      mutating++;
      try {
        const res = await DL.apiAdd({ work_code: ctx.work_code, added_price: currentPrice, alert_threshold_yen: null });
        if (!res) {
          restoreState(prev);
          updateBar();
          alert("お気に入り登録に失敗しました。時間をおいて再度お試しください。");
          return;
        }
        applyAddResult(res);
        updateBar();
      } finally { mutating--; }
    }

    // 最安値で通知: 通期最安をそのまま通知価格として保存 (未登録なら追加も同時に)
    async function doLowest() {
      if (allTimeMin == null || mutating) return;
      const prev = snapshotState();
      registered = true;            // 楽観更新: 即「最安値で通知中」表示へ
      currentThreshold = allTimeMin;
      updateBar();
      mutating++;
      try {
        let res;
        if (!prev.registered) {
          res = await DL.apiAdd({ work_code: ctx.work_code, added_price: currentPrice, alert_threshold_yen: allTimeMin });
          if (res) {
            applyAddResult(res);
            // 別ストアで登録済 (was_dup) の場合は add では閾値が変わらないので PATCH で揃える
            if (res.was_dup && Number(res.alert_threshold_yen) !== Number(allTimeMin)) {
              res = await DL.apiPatch(registeredCode, allTimeMin);
            }
            currentThreshold = allTimeMin;
          }
        } else {
          res = await DL.apiPatch(prev.registeredCode, allTimeMin);
        }
        if (!res) {
          restoreState(prev);
          updateBar();
          alert("通知価格の保存に失敗しました。時間をおいて再度お試しください。");
          return;
        }
        currentThreshold = allTimeMin;
        updateBar();
      } finally { mutating--; }
    }

    async function doSave() {
      if (mutating) return;
      const raw = thresholdInput.value.trim();
      const val = raw === "" ? null : Math.max(0, Math.floor(Number(raw)) || 0);
      const prev = snapshotState();
      currentThreshold = val;       // 楽観更新
      updateBar();
      mutating++;
      try {
        const res = await DL.apiPatch(registeredCode, val);
        if (!res) {
          restoreState(prev);
          updateBar();
          alert("通知価格の更新に失敗しました。");
          return;
        }
      } finally { mutating--; }
    }

    async function doRemove() {
      if (mutating) return;
      if (!confirm("ウォッチリストから解除しますか？")) return;
      const prev = snapshotState();
      registeredCode = ctx.work_code;  // 楽観更新: 即「フォローする」表示へ
      registered = false;
      currentThreshold = null;
      updateBar();
      mutating++;
      try {
        const ok = await DL.apiRemove(prev.registeredCode);
        if (!ok) {
          restoreState(prev);
          updateBar();
          alert("解除に失敗しました。時間をおいて再度お試しください。");
        }
      } finally { mutating--; }
    }

    followBtn.addEventListener("click", doFollow);
    lowestBtn.addEventListener("click", doLowest);
    saveBtn.addEventListener("click", doSave);
    removeBtn.addEventListener("click", doRemove);

    // ---------- hydrate: 登録済み判定 (list) ----------
    async function hydrate() {
      if (mutating) return;  // 楽観更新の最中に古い一覧で上書きしない
      const list = await DL.apiList();
      if (mutating) return;
      const own = list?.items?.find((it) =>
        it.work_code === ctx.work_code ||
        (it.stores || []).some((s) => s.work_code === ctx.work_code)
      );
      if (own) {
        registeredCode = own.work_code;
        registered = true;
        currentThreshold = own.alert_threshold_yen ?? null;
        if (currentPrice == null && own.current_price != null) currentPrice = own.current_price;
      } else {
        registeredCode = ctx.work_code;
        registered = false;
        currentThreshold = null;
      }
      updateBar();
    }
    setLoading();
    loadWork();
    hydrate();

    // Live sync: 他 context の変更 / 30s poll / タブ復帰
    DL.onLiveChange(() => hydrate());
    const pollId = setInterval(() => { if (document.visibilityState === "visible") hydrate(); }, 30000);
    const onVis = () => { if (document.visibilityState === "visible") hydrate(); };
    document.addEventListener("visibilitychange", onVis);
    const observer = new MutationObserver(() => {
      if (!document.contains(panel)) {
        clearInterval(pollId);
        document.removeEventListener("visibilitychange", onVis);
        ro.disconnect();
        observer.disconnect();
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });

    return panel;
  }

  DL.renderPanel = function renderPanel(ctx, mountEl, position = "before") {
    if (!mountEl) return null;
    document.getElementById("dl-panel")?.remove();
    const panel = buildPanel(ctx);
    if (position === "before") mountEl.parentNode.insertBefore(panel, mountEl);
    else if (position === "after") mountEl.parentNode.insertBefore(panel, mountEl.nextSibling);
    else if (position === "prepend") mountEl.prepend(panel);
    else mountEl.appendChild(panel);
    return panel;
  };
})();
