// DL-056 (2026-09-12): doujin-labo.net を開いたら、サイト側 (localStorage) の device_id を
// background へ渡して拡張の device と同じ group に自動合流させる。
// これで「サイトで♡ → 拡張にも出る」がコード入力なしで常に成立する。
// (content script は同一 origin の localStorage をそのまま読める)
(function () {
  const LS_KEY = "dl_fav_device_v1";
  function read() {
    try {
      const raw = localStorage.getItem(LS_KEY);
      if (!raw) return null;
      const j = JSON.parse(raw);
      return j && /^[0-9a-f]{32}$/.test(j.device_id || "") ? j.device_id : null;
    } catch (e) {
      return null;
    }
  }
  function send() {
    const did = read();
    if (!did) return false;
    try {
      chrome.runtime.sendMessage({ type: "dl:site-device", device_id: did }, () => void chrome.runtime.lastError);
    } catch (e) { /* 拡張が更新直後で無効化されている等 */ }
    return true;
  }
  // サイト側の ensureDevice は初回アクセス時に非同期でサーバーから device_id をもらうので、
  // 無ければ少し待って再試行 (最大 10 秒)
  if (!send()) {
    let n = 0;
    const t = setInterval(() => { if (send() || ++n >= 10) clearInterval(t); }, 1000);
  }
})();
