// doujin-labo Chrome 拡張 - 価格チャート (拡張内ネイティブ描画版)
//
// 2026-09-29 (v0.5.0): これまで iframe (doujin-labo.net/w/{id}/embed) に任せていたチャートを
// 拡張側で SVG 描画するようにした。データ整形ロジックは frontend/components/chart-embed-panel.jsx
// (_buildDailyBySite / _forwardFill / _findDiscountBands / model / view) の移植。
//
// 追加: カーソルオーバーで縦横のクロスヘア (日付バッジ + 価格バッジ + ストア別ツールチップ)。
//
// 2026-09-30 (v0.6.0, お父さま指示):
//   - グラフ中央にサイト名ウォーターマーク (doujin-labo.net)
//   - 期間タブに「1年」を追加 (既定は panel.js 側で 1年)
//   - pokeca-chart 風の全期間ミニチャート (brush)。左右ハンドル / 窓のドラッグで表示範囲を自由に選べる
//
// 公開 API (self.DL.chart):
//   PERIODS / SITE / yen
//   buildModel(workJson)            -> model
//   buildView(model, periodKey)     -> view
//   periodRange(model, periodKey)   -> {from, to} (期間タブ → 日付範囲)
//   buildViewRange(model, from, to) -> view (任意の日付範囲。brush 用)
//   brush(container, {model, onChange(from, to)}) -> {set(from, to), render()}
//   render(container, {view, model, focusSite}) -> SVG を container に描画 (再描画は毎回 innerHTML を消す)

(function () {
  const DL = self.DL || (self.DL = {});

  const SITE = {
    dlsite: { color: "#0f6bb5", label: "DLsite" },
    fanza: { color: "#dd1a1a", label: "FANZA" },
  };
  const PERIODS = [
    { key: "m1", label: "1ヶ月", days: 30 },
    { key: "m3", label: "3ヶ月", days: 90 },
    { key: "y1", label: "1年", days: 365 },   // 2026-09-30: 既定 (panel.js)
    { key: "all", label: "全期間", days: null },
  ];
  const INK = "#111827";
  const MUTED = "#6b7280";
  const LIST_DASH = "#9aa1a9";
  const ACCENT = "#F34B9F";
  const FONT = 'system-ui, -apple-system, "Hiragino Sans", "Hiragino Kaku Gothic ProN", Meiryo, sans-serif';

  const yen = (n) => (n == null ? "—" : Number(n).toLocaleString() + "円");
  const isoAddDays = (iso, d) => {
    const dt = new Date(iso + "T00:00:00Z");
    dt.setUTCDate(dt.getUTCDate() + d);
    return dt.toISOString().slice(0, 10);
  };
  const isoDiff = (a, b) => {
    const da = new Date(a + "T00:00:00Z");
    const db = new Date(b + "T00:00:00Z");
    return Math.round((db - da) / 86400000);
  };
  const fmtDate = (iso) => iso.replace(/-/g, "/");

  // ---------- data shaping (chart-embed-panel.jsx の移植) ----------
  function buildDailyBySite(sales_daily, price_history) {
    const bySite = { dlsite: {}, fanza: {} };
    for (const r of price_history || []) {
      if (r.price == null || !r.date || !r.site) continue;
      if (!bySite[r.site]) bySite[r.site] = {};
      const cur = bySite[r.site][r.date];
      if (cur == null || r.price < cur) bySite[r.site][r.date] = r.price;
    }
    for (const r of sales_daily || []) {
      if (r.price == null || !r.date || !r.site) continue;
      if (!bySite[r.site]) bySite[r.site] = {};
      bySite[r.site][r.date] = r.price; // sales_daily は snapshot 精度が高いので優先
    }
    return bySite;
  }

  function forwardFill(fromIso, toIso, sourceByDate) {
    const out = [];
    const days = isoDiff(fromIso, toIso);
    if (days < 0) return out;
    let last = null;
    for (const d of Object.keys(sourceByDate).sort()) {
      if (d > fromIso) break;
      last = sourceByDate[d];
    }
    for (let i = 0; i <= days; i++) {
      const iso = isoAddDays(fromIso, i);
      if (sourceByDate[iso] != null) last = sourceByDate[iso];
      out.push({ date: iso, price: last });
    }
    return out;
  }

  function buildModel(data) {
    const bySite = buildDailyBySite(data?.sales_daily, data?.price_history);
    const sites = Object.keys(bySite).filter((s) => Object.keys(bySite[s]).length > 0);
    if (!sites.length) return { empty: true };

    const allDates = new Set();
    for (const s of sites) for (const d of Object.keys(bySite[s])) allDates.add(d);
    const dates = [...allDates].sort();
    const observedFrom = dates[0];
    const observedTo = dates[dates.length - 1];

    // 定価: サイト別最大値の最大 (最も高い値が定価に近い)
    let listPrice = 0;
    for (const s of sites) {
      const mx = Math.max(...Object.values(bySite[s]));
      if (mx > listPrice) listPrice = mx;
    }
    if (!listPrice) listPrice = null;

    const currentBySite = {};
    for (const s of sites) {
      const ds = Object.keys(bySite[s]).sort();
      currentBySite[s] = bySite[s][ds[ds.length - 1]];
    }
    const currents = Object.values(currentBySite).filter((p) => p != null);
    const currentPrice = currents.length ? Math.min(...currents) : null;

    let allTimeMin = null;
    for (const s of sites) {
      const mn = Math.min(...Object.values(bySite[s]));
      if (allTimeMin == null || mn < allTimeMin) allTimeMin = mn;
    }
    const allPricesFlat = sites.flatMap((s) => Object.values(bySite[s]));
    const priorPrices = allPricesFlat.filter((p) => p !== currentPrice);
    const priorMin = priorPrices.length ? Math.min(...priorPrices) : allTimeMin;

    return {
      empty: false,
      sites, bySite, dates, observedFrom, observedTo,
      listPrice, currentPrice, currentBySite, allTimeMin, priorMin,
    };
  }

  function periodRange(model, periodKey) {
    const period = PERIODS.find((p) => p.key === periodKey) || PERIODS[PERIODS.length - 1];
    const to = model.observedTo;
    let from;
    if (period.days) {
      from = isoAddDays(to, -(period.days - 1));
      if (from < model.observedFrom) from = model.observedFrom;
    } else {
      from = model.observedFrom;
    }
    return { from, to, period };
  }

  function buildViewRange(model, from, to, period = null) {
    if (!model || model.empty) return null;
    if (from < model.observedFrom) from = model.observedFrom;
    if (to > model.observedTo) to = model.observedTo;
    if (from > to) from = to;
    const seriesBySite = {};
    for (const s of model.sites) seriesBySite[s] = forwardFill(from, to, model.bySite[s]);
    const periodPricesFlat = model.sites.flatMap((s) => seriesBySite[s].map((r) => r.price).filter((p) => p != null));
    const periodMin = periodPricesFlat.length ? Math.min(...periodPricesFlat) : null;
    const isAllTimeLow = model.currentPrice != null && model.currentPrice === model.allTimeMin;
    const off = model.listPrice && model.currentPrice != null && model.currentPrice < model.listPrice
      ? Math.round((1 - model.currentPrice / model.listPrice) * 100)
      : 0;
    return { period, from, to, seriesBySite, periodMin, isAllTimeLow, off };
  }

  function buildView(model, periodKey) {
    if (!model || model.empty) return null;
    const r = periodRange(model, periodKey);
    return buildViewRange(model, r.from, r.to, r.period);
  }

  // ---------- SVG helpers ----------
  const NS = "http://www.w3.org/2000/svg";
  function svgEl(tag, attrs, ...children) {
    const e = document.createElementNS(NS, tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v == null) continue;
      e.setAttribute(k, v);
    }
    for (const c of children) {
      if (c == null) continue;
      e.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
    }
    return e;
  }

  // 目盛り幅を「1 / 2 / 5 × 10^n」に丸める
  function niceStep(range, target) {
    if (!(range > 0)) return 1;
    const rough = range / target;
    const pow = Math.pow(10, Math.floor(Math.log10(rough)));
    const f = rough / pow;
    const m = f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10;
    return m * pow;
  }

  // ---------- render ----------
  function render(container, opts) {
    const { view, model, focusSite } = opts;
    container.innerHTML = "";
    container.classList.add("dl-ch");

    const sites = Object.keys(view.seriesBySite).filter((s) => view.seriesBySite[s].length >= 2);
    const anySeries = sites.length ? view.seriesBySite[sites[0]] : null;
    const W = Math.max(320, Math.floor(container.clientWidth || 900));
    const H = DL.CHART_H || 220; // 2026-09-29 お父さま「窮屈」→ 150 → 220。ストア版 (小型) は DL.CHART_H で下げる
    if (!anySeries || anySeries.length < 2) {
      const svg0 = svgEl("svg", { viewBox: `0 0 ${W} ${H}`, width: "100%", height: H, class: "dl-ch-svg" },
        svgEl("text", { x: W / 2, y: H / 2, "text-anchor": "middle", fill: LIST_DASH, "font-size": 12, "font-family": FONT }, "価格データが不足しています"));
      container.appendChild(svg0);
      return;
    }

    const PL = 50, PR = 14, PT = 10, PB = 22;
    const IW = W - PL - PR, IH = H - PT - PB;
    const allPrices = sites.flatMap((s) => view.seriesBySite[s].map((r) => r.price).filter((p) => p != null));
    // 縦軸は 0 起点ではなく価格帯に合わせる (値動きの視認性優先。2026-09-29 お父さま指示)。
    // 下 25% / 上 15% の余白を付け、目盛りは 1/2/5 刻みに丸める。値動きが無い作品は ±20% の幅で見せる。
    const rawMax = Math.max(...allPrices, model.listPrice || 0) || 1000;
    const rawMin = Math.min(...allPrices);
    let range = rawMax - rawMin;
    if (!(range > 0)) range = Math.max(rawMax * 0.2, 50);
    const lo = rawMin - range * 0.25;
    const hi = rawMax + range * 0.15;
    const step = niceStep(hi - lo, 5);
    const minY = Math.max(0, Math.floor(lo / step) * step);
    let maxY = Math.ceil(hi / step) * step;
    if (maxY <= minY) maxY = minY + step;
    const fromIso = anySeries[0].date;
    const toIso = anySeries[anySeries.length - 1].date;
    const totalDays = Math.max(1, isoDiff(fromIso, toIso));
    const xAt = (iso) => PL + (IW * isoDiff(fromIso, iso)) / totalDays;
    const xAtDay = (i) => PL + (IW * i) / totalDays;
    const yAt = (v) => PT + IH - (IH * (v - minY)) / (maxY - minY);

    const svg = svgEl("svg", {
      viewBox: `0 0 ${W} ${H}`, width: "100%", height: H, class: "dl-ch-svg",
      role: "img", "aria-label": "価格推移グラフ",
    });

    // (割引期間の薄赤バンドは 2026-09-30 お父さま指示で廃止。割引はステップラインの谷で読める)

    // Y グリッド + ラベル
    for (let v = minY; v <= maxY + 1e-6; v += step) {
      const y = yAt(v);
      svg.appendChild(svgEl("line", { x1: PL, y1: y, x2: W - PR, y2: y, stroke: v === minY ? "#c9ced6" : "#eff1f4", "stroke-width": 1 }));
      svg.appendChild(svgEl("text", { x: PL - 6, y: y + 3, "text-anchor": "end", fill: MUTED, "font-size": 9.5, "font-family": FONT }, Math.round(v).toLocaleString()));
    }

    // サイト名ウォーターマーク (2026-09-30 お父さま指示)。折れ線より下のレイヤーに薄く敷く
    svg.appendChild(svgEl("text", {
      x: PL + IW / 2, y: PT + IH / 2 + Math.min(11, IH / 8),
      "text-anchor": "middle", fill: ACCENT, opacity: 0.09,
      "font-size": Math.max(15, Math.min(30, IW / 13)), "font-weight": 800,
      "font-family": FONT, "letter-spacing": "0.08em", "pointer-events": "none",
    }, DL.WATERMARK ?? "doujin-labo.net"));  // グラフ特化版 (extension-chart) は URL にならない表記へ差し替える

    // X 目盛り (幅に応じて本数を変える)
    const nTicks = Math.min(8, Math.max(2, Math.round(IW / 130)));
    const longSpan = totalDays > 400;
    for (let i = 0; i < nTicks; i++) {
      const off = Math.round((i * totalDays) / (nTicks - 1));
      const iso = isoAddDays(fromIso, off);
      const x = xAtDay(off);
      if (i > 0 && i < nTicks - 1) {
        svg.appendChild(svgEl("line", { x1: x, y1: PT, x2: x, y2: PT + IH, stroke: "#f1f3f6", "stroke-width": 1 }));
      }
      const label = longSpan ? iso.slice(2, 7).replace("-", "/") : iso.slice(5).replace("-", "/");
      const anchor = i === 0 ? "start" : i === nTicks - 1 ? "end" : "middle";
      svg.appendChild(svgEl("text", { x, y: H - 7, "text-anchor": anchor, fill: MUTED, "font-size": 9.5, "font-family": FONT }, label));
    }

    // 定価 (破線)
    if (model.listPrice != null && model.listPrice >= minY && model.listPrice <= maxY) {
      const y = yAt(model.listPrice);
      svg.appendChild(svgEl("line", { x1: PL, y1: y, x2: W - PR, y2: y, stroke: LIST_DASH, "stroke-width": 1.4, "stroke-dasharray": "6 5" }));
    }

    // ストア別ステップライン
    for (const s of sites) {
      const color = SITE[s]?.color || INK;
      const series = view.seriesBySite[s];
      let d = "";
      for (let i = 0; i < series.length; i++) {
        const p = series[i].price;
        if (p == null) continue;
        const x = xAtDay(i), y = yAt(p);
        d += d ? `H${x.toFixed(1)}V${y.toFixed(1)}` : `M${x.toFixed(1)} ${y.toFixed(1)}`;
      }
      svg.appendChild(svgEl("path", { d, fill: "none", stroke: color, "stroke-width": 2, "stroke-linejoin": "round", opacity: 0.92 }));
      const last = series[series.length - 1];
      if (last?.price != null) {
        svg.appendChild(svgEl("circle", { cx: xAtDay(series.length - 1), cy: yAt(last.price), r: 3.4, fill: color, stroke: "#fff", "stroke-width": 1.2 }));
      }
    }

    // ---- クロスヘア (縦線 + 横線 + 軸バッジ + 各ストアの点) ----
    const cross = svgEl("g", { class: "dl-ch-cross", style: "display:none" });
    const vLine = svgEl("line", { y1: PT, y2: PT + IH, stroke: "#475569", "stroke-width": 1, "stroke-dasharray": "3 3" });
    const hLine = svgEl("line", { x1: PL, x2: W - PR, stroke: "#475569", "stroke-width": 1, "stroke-dasharray": "3 3" });
    const xBadgeRect = svgEl("rect", { height: 16, rx: 3, fill: "#1f2937" });
    const xBadgeText = svgEl("text", { "text-anchor": "middle", fill: "#fff", "font-size": 10, "font-weight": 700, "font-family": FONT });
    const yBadgeRect = svgEl("rect", { x: 2, height: 16, width: PL - 6, rx: 3, fill: "#1f2937" });
    const yBadgeText = svgEl("text", { x: PL - 6, "text-anchor": "end", fill: "#fff", "font-size": 10, "font-weight": 700, "font-family": FONT });
    cross.appendChild(vLine);
    cross.appendChild(hLine);
    cross.appendChild(xBadgeRect);
    cross.appendChild(xBadgeText);
    cross.appendChild(yBadgeRect);
    cross.appendChild(yBadgeText);
    const dots = {};
    for (const s of sites) {
      dots[s] = svgEl("circle", { r: 4.2, fill: "#fff", stroke: SITE[s]?.color || INK, "stroke-width": 2.2 });
      cross.appendChild(dots[s]);
    }
    svg.appendChild(cross);

    // ポインタ受け (プロット領域全面)
    const hit = svgEl("rect", { x: PL, y: PT, width: IW, height: IH, fill: "transparent", style: "cursor: crosshair; touch-action: none" });
    svg.appendChild(hit);
    container.appendChild(svg);

    const tip = document.createElement("div");
    tip.className = "dl-ch-tip";
    tip.hidden = true;
    container.appendChild(tip);

    const hide = () => { cross.style.display = "none"; tip.hidden = true; };

    const move = (clientX, clientY) => {
      const rect = svg.getBoundingClientRect();
      if (rect.width === 0) return;
      const vx = ((clientX - rect.left) / rect.width) * W;
      const ratio = (vx - PL) / IW;
      if (ratio < -0.03 || ratio > 1.03) return hide();
      const dayIdx = Math.round(Math.min(Math.max(ratio, 0), 1) * totalDays);
      const iso = isoAddDays(fromIso, dayIdx);
      const x = xAtDay(dayIdx);

      // その日の各ストア価格 (forwardFill 済みなので index 直引き)
      const rows = [];
      let focusPrice = null;
      for (const s of sites) {
        const p = view.seriesBySite[s][dayIdx]?.price;
        if (p == null) { dots[s].style.display = "none"; continue; }
        dots[s].style.display = "";
        dots[s].setAttribute("cx", x);
        dots[s].setAttribute("cy", yAt(p));
        rows.push({ site: s, price: p });
        if (s === focusSite) focusPrice = p;
      }
      if (focusPrice == null && rows.length) focusPrice = Math.min(...rows.map((r) => r.price));

      vLine.setAttribute("x1", x);
      vLine.setAttribute("x2", x);
      const dateLabel = fmtDate(iso);
      const bw = Math.max(58, dateLabel.length * 6.4 + 10);
      const bx = Math.min(Math.max(x - bw / 2, PL), W - PR - bw);
      xBadgeRect.setAttribute("x", bx);
      xBadgeRect.setAttribute("y", PT + IH + 3);
      xBadgeRect.setAttribute("width", bw);
      xBadgeText.setAttribute("x", bx + bw / 2);
      xBadgeText.setAttribute("y", PT + IH + 15);
      xBadgeText.textContent = dateLabel;

      if (focusPrice != null) {
        const y = yAt(focusPrice);
        hLine.style.display = "";
        yBadgeRect.style.display = "";
        yBadgeText.style.display = "";
        hLine.setAttribute("y1", y);
        hLine.setAttribute("y2", y);
        yBadgeRect.setAttribute("y", Math.min(Math.max(y - 8, PT - 6), PT + IH - 10));
        yBadgeText.setAttribute("y", Math.min(Math.max(y - 8, PT - 6), PT + IH - 10) + 12);
        yBadgeText.textContent = Math.round(focusPrice).toLocaleString();
      } else {
        hLine.style.display = "none";
        yBadgeRect.style.display = "none";
        yBadgeText.style.display = "none";
      }
      cross.style.display = "";

      // ツールチップ
      const lp = model.listPrice;
      const html = [`<div class="dl-ch-tip-date">${dateLabel}</div>`];
      for (const r of rows) {
        const st = SITE[r.site] || { color: INK, label: r.site };
        const off = lp && r.price < lp ? Math.round((1 - r.price / lp) * 100) : 0;
        html.push(
          `<div class="dl-ch-tip-row"><span class="dl-ch-tip-dot" style="background:${st.color}"></span>` +
          `<span class="dl-ch-tip-site">${st.label}</span><span class="dl-ch-tip-price">${yen(r.price)}</span>` +
          (off > 0 ? `<span class="dl-ch-tip-off">${off}%OFF</span>` : "") + `</div>`
        );
      }
      if (!rows.length) html.push(`<div class="dl-ch-tip-row"><span class="dl-ch-tip-site">観測なし</span></div>`);
      if (lp) html.push(`<div class="dl-ch-tip-sub">定価 ${yen(lp)}</div>`);
      tip.innerHTML = html.join("");
      tip.hidden = false;
      const cRect = container.getBoundingClientRect();
      const px = clientX - cRect.left;
      const py = clientY - cRect.top;
      const flip = px > cRect.width - 170;
      tip.style.left = `${flip ? px - 14 : px + 14}px`;
      tip.style.transform = flip ? "translateX(-100%)" : "none";
      const tipH = tip.offsetHeight || 60;
      tip.style.top = `${Math.min(Math.max(py - tipH / 2, 2), H - tipH - 2)}px`;
    };

    hit.addEventListener("pointermove", (e) => move(e.clientX, e.clientY));
    hit.addEventListener("pointerdown", (e) => move(e.clientX, e.clientY));
    hit.addEventListener("pointerleave", hide);
    hit.addEventListener("pointercancel", hide);
  }

  // ---------- 期間ブラシ (pokeca-chart 風、2026-09-30 お父さま指示) ----------
  // 全期間の最安値 (両ストア min) を薄い面グラフで敷き、その上の選択窓を
  // 左右ハンドル (端の日付) / 窓の中 (期間ごと平行移動) のドラッグで動かす。
  // 窓の外をクリックするとその位置へ窓ごとジャンプ。動くたびに onChange(fromIso, toIso) が rAF で 1 回来る。
  function brush(container, opts) {
    const { model, onChange } = opts;
    const fullFrom = model.observedFrom;
    const fullTo = model.observedTo;
    const totalDays = Math.max(1, isoDiff(fullFrom, fullTo));
    const MIN_SPAN = Math.min(7, totalDays);
    let selL = 0, selR = totalDays;        // 選択窓 (day index)
    let W = 0, IW = 0;
    const H = 44, PL = 50, PR = 14, PT = 3, PB = 14;
    const IH = H - PT - PB;
    let svg = null, winRect = null, dimL = null, dimR = null, handleL = null, handleR = null;

    // 観測が短い作品はブラシを出す意味が無い (タブだけで足りる)
    if (totalDays < 14) {
      container.style.display = "none";
      return { set() {}, render() {} };
    }

    // 全期間の日次最安 (両ストアの min)。概形が分かれば良いので 1 本にまとめる
    const merged = {};
    for (const s of model.sites) {
      for (const [d, p] of Object.entries(model.bySite[s])) {
        if (merged[d] == null || p < merged[d]) merged[d] = p;
      }
    }
    const series = forwardFill(fullFrom, fullTo, merged);

    const xAtDay = (i) => PL + (IW * i) / totalDays;
    const dayAt = (clientX) => {
      const rect = svg.getBoundingClientRect();
      const vx = ((clientX - rect.left) / rect.width) * W;
      return Math.round(Math.min(Math.max((vx - PL) / IW, 0), 1) * totalDays);
    };

    function position() {
      const x1 = xAtDay(selL), x2 = xAtDay(selR);
      winRect.setAttribute("x", x1);
      winRect.setAttribute("width", Math.max(1, x2 - x1));
      dimL.setAttribute("width", Math.max(0, x1 - PL));
      dimR.setAttribute("x", x2);
      dimR.setAttribute("width", Math.max(0, PL + IW - x2));
      handleL.setAttribute("transform", `translate(${x1},0)`);
      handleR.setAttribute("transform", `translate(${x2},0)`);
    }

    let rafId = 0;
    function emit() {
      cancelAnimationFrame(rafId);
      rafId = requestAnimationFrame(() => onChange(isoAddDays(fullFrom, selL), isoAddDays(fullFrom, selR)));
    }

    function mkHandle() {
      const g = svgEl("g", { style: "cursor: ew-resize" });
      g.appendChild(svgEl("rect", { x: -5.5, y: PT + 1, width: 11, height: IH - 2, rx: 3, fill: "#fff", stroke: "#c8175d", "stroke-width": 1.4 }));
      g.appendChild(svgEl("line", { x1: -1.8, y1: PT + 8, x2: -1.8, y2: PT + IH - 8, stroke: "#c8175d", "stroke-width": 1.2 }));
      g.appendChild(svgEl("line", { x1: 1.8, y1: PT + 8, x2: 1.8, y2: PT + IH - 8, stroke: "#c8175d", "stroke-width": 1.2 }));
      return g;
    }

    function render() {
      W = Math.max(320, Math.floor(container.clientWidth || 900));
      IW = W - PL - PR;
      container.innerHTML = "";
      svg = svgEl("svg", {
        viewBox: `0 0 ${W} ${H}`, width: "100%", height: H, class: "dl-ch-brush",
        role: "slider", "aria-label": "表示期間の選択 (ドラッグで変更)",
      });
      svg.appendChild(svgEl("rect", { x: PL, y: PT, width: IW, height: IH, fill: "#f5f6f8", stroke: "#e5e7eb", "stroke-width": 1 }));
      const prices = series.map((r) => r.price).filter((p) => p != null);
      if (prices.length) {
        const mx = Math.max(...prices);
        const mn = Math.min(...prices);
        const span = Math.max(1, mx - mn);
        const yAt = (v) => PT + 3 + (IH - 6) * (1 - (v - mn) / span);
        let d = "", started = false;
        for (let i = 0; i < series.length; i++) {
          const p = series[i].price;
          if (p == null) continue;
          const x = xAtDay(i).toFixed(1), y = yAt(p).toFixed(1);
          d += started ? `L${x} ${y}` : `M${x} ${PT + IH}L${x} ${y}`;
          started = true;
        }
        if (started) {
          d += `L${xAtDay(series.length - 1).toFixed(1)} ${PT + IH}Z`;
          svg.appendChild(svgEl("path", { d, fill: "#dfe3e9", stroke: "#b6bdc9", "stroke-width": 1 }));
        }
      }
      dimL = svgEl("rect", { x: PL, y: PT, height: IH, width: 0, fill: "rgba(255,255,255,.72)" });
      dimR = svgEl("rect", { y: PT, height: IH, width: 0, fill: "rgba(255,255,255,.72)" });
      winRect = svgEl("rect", { y: PT, height: IH, fill: "rgba(243,75,159,.10)", stroke: ACCENT, "stroke-width": 1.4, style: "cursor: grab" });
      handleL = mkHandle();
      handleR = mkHandle();
      svg.appendChild(dimL);
      svg.appendChild(dimR);
      svg.appendChild(winRect);
      svg.appendChild(handleL);
      svg.appendChild(handleR);
      svg.appendChild(svgEl("text", { x: PL, y: H - 3, fill: MUTED, "font-size": 9, "font-family": FONT }, fmtDate(fullFrom)));
      svg.appendChild(svgEl("text", { x: PL + IW, y: H - 3, "text-anchor": "end", fill: MUTED, "font-size": 9, "font-family": FONT }, fmtDate(fullTo)));
      container.appendChild(svg);
      position();

      let mode = null, grabOff = 0;
      svg.addEventListener("pointerdown", (e) => {
        const rect = svg.getBoundingClientRect();
        const vx = ((e.clientX - rect.left) / rect.width) * W;
        const xL = xAtDay(selL), xR = xAtDay(selR);
        if (Math.abs(vx - xL) <= 9) mode = "l";
        else if (Math.abs(vx - xR) <= 9) mode = "r";
        else if (vx > xL && vx < xR) {
          mode = "m";
          grabOff = dayAt(e.clientX) - selL;
        } else {
          const w = selR - selL;
          selL = Math.min(Math.max(0, dayAt(e.clientX) - Math.round(w / 2)), totalDays - w);
          selR = selL + w;
          mode = "m";
          grabOff = dayAt(e.clientX) - selL;
          position();
          emit();
        }
        svg.setPointerCapture(e.pointerId);
        e.preventDefault();
      });
      svg.addEventListener("pointermove", (e) => {
        if (!mode) return;
        const d = dayAt(e.clientX);
        if (mode === "l") selL = Math.min(Math.max(0, d), selR - MIN_SPAN);
        else if (mode === "r") selR = Math.max(Math.min(totalDays, d), selL + MIN_SPAN);
        else {
          const w = selR - selL;
          selL = Math.min(Math.max(0, d - grabOff), totalDays - w);
          selR = selL + w;
        }
        position();
        emit();
      });
      const end = () => { mode = null; };
      svg.addEventListener("pointerup", end);
      svg.addEventListener("pointercancel", end);
    }

    function set(fromIso, toIso) {
      selL = Math.min(Math.max(0, isoDiff(fullFrom, fromIso)), totalDays);
      selR = Math.min(Math.max(selL + 1, isoDiff(fullFrom, toIso)), totalDays);
      if (winRect) position();
    }

    return { set, render };
  }

  DL.chart = { PERIODS, SITE, ACCENT, yen, fmtDate, buildModel, buildView, buildViewRange, periodRange, brush, render,
    // extension-chart/content/sales-chart.js が使う下回り
    util: { svgEl, niceStep, isoAddDays, isoDiff, FONT, MUTED, INK } };
})();
